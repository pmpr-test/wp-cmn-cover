<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517377ff95             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Metadata; use Pmpr\Common\Cover\Container; abstract class Common extends Container { const oswseauqqwwuiwcg = "\155\x65\164\141\144\141\164\141\137"; }
