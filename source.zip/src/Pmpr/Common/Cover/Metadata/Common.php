<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67059fda52cde             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Metadata; use Pmpr\Common\Cover\Container; abstract class Common extends Container { const oswseauqqwwuiwcg = "\155\x65\164\141\144\x61\x74\141\x5f"; }
