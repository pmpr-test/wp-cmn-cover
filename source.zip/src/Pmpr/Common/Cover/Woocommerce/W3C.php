<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a0bc44e650d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Woocommerce; use Pmpr\Common\Cover\Container; class W3C extends Container { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('woocommerce_before_quantity_input_field', [$this, 'oeasawmuksmcigsk'], 0)->qcsmikeggeemccuu('woocommerce_after_quantity_input_field', [$this, 'osawiwkkmgiamgww'], PHP_INT_MAX); } public function oeasawmuksmcigsk() { ob_start(); } public function osawiwkkmgiamgww() { $nsmgceoqaqogqmuw = ob_get_clean(); $kasgukgceywckyou = $this->caokeucsksukesyo()->gkksucgseqqemesc(); if ($kasgukgceywckyou->has($nsmgceoqaqogqmuw, 'input[type=hidden]')) { $nsmgceoqaqogqmuw = $kasgukgceywckyou->suygukqgsuwaaumg($nsmgceoqaqogqmuw, 'label'); $nsmgceoqaqogqmuw = $kasgukgceywckyou->ogaeogwycyqqckeu($nsmgceoqaqogqmuw, ['input[type=hidden]' => ['autocomplete', 'placeholder', 'aria-label', 'inputmode', 'size', 'step', 'min', 'max']]); } echo $nsmgceoqaqogqmuw; } }
