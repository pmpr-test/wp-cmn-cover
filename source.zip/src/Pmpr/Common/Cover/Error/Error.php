<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             692c4c318f585             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Error; use Pmpr\Common\Cover\Container; class Error extends Container { public function mameiwsayuyquoeq() { WPDie::symcgieuakksimmu(); } }
