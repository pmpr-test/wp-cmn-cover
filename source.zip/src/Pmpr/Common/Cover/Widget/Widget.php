<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67059fda52cde             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; use Pmpr\Common\Cover\Container; class Widget extends Container { public function mameiwsayuyquoeq() { Link::symcgieuakksimmu(); Post::symcgieuakksimmu(); Title::symcgieuakksimmu(); About::symcgieuakksimmu(); Search::symcgieuakksimmu(); License::symcgieuakksimmu(); Taxonomy::symcgieuakksimmu(); Metadata::symcgieuakksimmu(); Copyright::symcgieuakksimmu(); } }
