<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d88946bbc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Widget; class Title extends Widget { public function __construct() { parent::__construct(__("\124\151\x74\154\x65", PR__CMN__COVER), __("\x44\x69\x73\160\x6c\141\171\40\x74\150\x65\x20\x74\151\164\154\145\x2e", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\124\x65\x78\164", PR__CMN__COVER))); } }
