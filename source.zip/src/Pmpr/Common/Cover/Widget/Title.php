<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b083ce992             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Widget; use Pmpr\Common\Foundation\Interfaces\Constants; class Title extends Common { public function __construct() { parent::__construct(__("\x54\x69\164\154\145", PR__CMN__COVER), __("\104\151\x73\160\x6c\x61\171\x20\164\x68\x65\x20\x74\151\164\154\x65\x2e", PR__CMN__COVER)); } public function ykwqaukkycogooii() { $uuyucgkyusckoaeq = $this->caokeucsksukesyo()->wmkogisswkckmeua(); $this->mkksewyosgeumwsa($uuyucgkyusckoaeq->ymuegqgyuagyucws(Constants::TEXT)->gswweykyogmsyawy(__("\x54\145\x78\164", PR__CMN__COVER))); } }
