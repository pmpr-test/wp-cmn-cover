<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6990793a4b5a6             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting; abstract class Container extends BaseClass { public function kmuweyayaqoeqiyw() : ?Setting { return $this->caokeucsksukesyo()->ogciwyoqgciosgcw()->uqsqkugwgmugquio(); } }
