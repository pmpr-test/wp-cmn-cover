<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a63e13a0b54             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Setting; abstract class Container extends BaseClass { public function kmuweyayaqoeqiyw() : ?Setting { return $this->caokeucsksukesyo()->ogciwyoqgciosgcw()->uqsqkugwgmugquio(); } }
