<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             682fc6c6500ef             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\PageBuilder; use Pmpr\Common\Cover\Container; class PageBuilder extends Container { }
