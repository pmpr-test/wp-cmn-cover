<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e92d0253760             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\PageBuilder; use Pmpr\Common\Cover\Container; class PageBuilder extends Container { }
