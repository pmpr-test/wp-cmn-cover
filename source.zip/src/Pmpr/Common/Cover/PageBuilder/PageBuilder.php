<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cffeeccd8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\PageBuilder; use Pmpr\Common\Cover\Container; class PageBuilder extends Container { }
