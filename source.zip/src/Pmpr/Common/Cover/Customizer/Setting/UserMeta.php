<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689c7ea1363b7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; class UserMeta extends Setting { }
