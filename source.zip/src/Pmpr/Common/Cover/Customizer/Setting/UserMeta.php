<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6800f6e896efa             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; class UserMeta extends Setting { }
