<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a63e13a0b54             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; class UserMeta extends Setting { }
