<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681fcb5041abc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; class UserMeta extends Setting { }
