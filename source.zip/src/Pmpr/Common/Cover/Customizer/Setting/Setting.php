<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038b8edf05             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\150\x65\x6d\x65\x5f\155\x6f\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\141\x6e\163\x70\157\162\164" => "\162\x65\x66\x72\x65\x73\150", "\143\141\160\x61\142\151\154\151\x74\x79" => "\145\x64\151\x74\137\164\x68\x65\x6d\x65\137\157\160\164\x69\157\156\x73", "\144\145\146\x61\x75\154\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\x61\x6e\x69\164\x69\x7a\145\x5f\x63\x61\x6c\154\142\141\x63\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
