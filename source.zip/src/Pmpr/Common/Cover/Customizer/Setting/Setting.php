<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67802fccab824             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\150\x65\155\145\137\155\x6f\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\x61\x6e\x73\160\157\162\x74" => "\162\x65\146\x72\x65\x73\x68", "\143\141\x70\x61\142\x69\154\151\164\x79" => "\x65\x64\x69\164\137\164\150\145\155\x65\137\157\x70\164\x69\x6f\156\163", "\x64\145\x66\x61\x75\154\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\x61\156\151\x74\151\x7a\145\137\143\141\x6c\x6c\142\x61\143\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
