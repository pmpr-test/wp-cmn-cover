<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed85a1ef6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\x68\x65\x6d\145\137\155\x6f\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\162\x61\x6e\x73\x70\x6f\x72\x74" => "\162\145\x66\x72\x65\x73\150", "\x63\141\x70\x61\x62\151\x6c\151\164\171" => "\x65\x64\x69\x74\x5f\x74\x68\x65\x6d\145\137\157\x70\x74\x69\157\156\163", "\144\145\x66\x61\165\154\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\141\156\151\x74\151\x7a\x65\137\143\x61\x6c\154\142\x61\143\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
