<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4443ec418             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\150\x65\x6d\145\137\155\157\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\162\x61\x6e\x73\160\157\162\x74" => "\x72\145\x66\162\x65\x73\150", "\143\x61\x70\x61\x62\x69\154\x69\164\x79" => "\x65\x64\151\x74\x5f\x74\150\x65\x6d\145\137\x6f\160\164\151\157\x6e\163", "\144\145\146\141\165\154\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\141\x6e\151\164\151\172\x65\x5f\143\x61\154\154\x62\141\143\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
