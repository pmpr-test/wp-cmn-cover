<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             674458708a1bd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\x68\145\x6d\145\137\x6d\x6f\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\162\141\156\163\160\157\162\x74" => "\162\145\x66\x72\145\163\150", "\143\x61\160\141\x62\x69\x6c\151\x74\171" => "\x65\x64\x69\164\x5f\164\150\x65\x6d\145\137\x6f\160\x74\x69\157\x6e\163", "\144\145\x66\x61\x75\154\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\141\x6e\x69\164\151\x7a\x65\x5f\x63\141\154\x6c\x62\141\x63\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
