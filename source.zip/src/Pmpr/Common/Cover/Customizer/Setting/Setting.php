<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc05648ef2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\150\145\155\145\x5f\155\157\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\162\141\x6e\x73\160\x6f\x72\x74" => "\x72\145\x66\x72\x65\x73\150", "\x63\x61\160\141\x62\x69\154\x69\164\x79" => "\145\x64\x69\x74\137\164\150\x65\x6d\x65\137\x6f\160\164\151\x6f\156\163", "\x64\145\x66\141\165\154\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\141\156\x69\x74\x69\x7a\x65\137\x63\x61\154\x6c\142\x61\x63\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
