<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed8109666a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\150\x65\x6d\145\137\x6d\157\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\x72\141\156\163\x70\157\162\164" => "\162\145\146\162\145\163\x68", "\143\141\x70\x61\142\151\154\x69\164\171" => "\x65\144\151\x74\137\x74\150\145\155\145\137\x6f\160\x74\151\x6f\156\163", "\x64\145\x66\x61\165\154\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\141\x6e\151\x74\151\172\145\137\143\141\154\154\x62\141\143\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
