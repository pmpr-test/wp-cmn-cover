<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd66b1d253             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\150\145\155\145\137\x6d\157\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\141\156\163\x70\157\x72\164" => "\x72\x65\x66\162\x65\163\x68", "\x63\141\160\141\x62\151\154\151\164\171" => "\x65\144\151\x74\137\164\x68\145\155\145\137\x6f\x70\164\x69\157\x6e\163", "\144\x65\x66\x61\x75\x6c\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\x61\156\x69\164\151\172\145\x5f\143\x61\154\154\142\x61\x63\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
