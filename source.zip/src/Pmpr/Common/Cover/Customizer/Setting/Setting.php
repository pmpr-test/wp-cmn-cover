<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6cfc9458             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\x68\x65\x6d\145\x5f\x6d\157\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\162\141\156\x73\160\x6f\x72\164" => "\162\x65\x66\162\x65\163\x68", "\143\141\x70\141\142\151\154\151\164\171" => "\145\x64\x69\164\137\164\x68\x65\x6d\145\137\157\160\164\151\157\x6e\x73", "\x64\145\x66\141\165\154\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\x61\x6e\151\164\x69\172\x65\137\143\141\x6c\154\142\141\143\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
