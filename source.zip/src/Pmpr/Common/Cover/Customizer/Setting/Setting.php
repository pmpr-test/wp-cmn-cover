<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             674459939f07b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\150\145\x6d\145\x5f\x6d\157\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\162\141\156\163\x70\157\162\x74" => "\162\145\146\x72\145\x73\x68", "\x63\141\x70\x61\x62\x69\154\151\x74\x79" => "\145\x64\151\164\137\x74\150\x65\x6d\145\137\x6f\160\164\151\157\156\163", "\144\145\146\x61\x75\154\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\x61\156\x69\164\x69\x7a\145\137\143\141\x6c\x6c\142\141\143\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
