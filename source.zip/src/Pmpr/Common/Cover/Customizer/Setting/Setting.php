<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fcbc08ae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\150\145\x6d\145\x5f\155\x6f\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\x72\x61\156\163\160\x6f\162\x74" => "\x72\145\146\162\145\x73\150", "\x63\x61\x70\141\142\x69\x6c\151\x74\171" => "\x65\x64\151\x74\137\x74\150\x65\155\x65\x5f\x6f\x70\x74\x69\157\156\x73", "\144\145\x66\141\165\x6c\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\x61\156\x69\x74\x69\172\145\x5f\143\x61\154\154\142\141\143\x6b" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
