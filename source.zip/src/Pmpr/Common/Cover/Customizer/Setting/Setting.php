<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716beac1a112             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\x74\x68\x65\155\x65\x5f\155\157\x64"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\164\x72\141\156\163\x70\x6f\162\x74" => "\x72\145\146\162\x65\163\x68", "\143\141\x70\141\142\151\154\x69\x74\171" => "\145\144\151\x74\x5f\164\150\x65\x6d\x65\x5f\157\x70\164\x69\x6f\156\163", "\x64\x65\146\141\165\154\164" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\x73\x61\x6e\151\164\x69\172\145\x5f\x63\141\154\154\142\141\143\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
