<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b083ce992             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; use Pmpr\Common\Foundation\Functions\Traits\HelperTrait; use Pmpr\Common\Foundation\Functions\Traits\WrapperTrait; use WP_Customize_Setting; class Setting extends WP_Customize_Setting { use WrapperTrait, HelperTrait; protected ?Field $field = null; public $type = "\164\x68\x65\155\x65\137\155\x6f\144"; public function __construct(Field $aiowsaccomcoikus, $eygsasmqycagyayw) { $this->field = $aiowsaccomcoikus; $ywmkwiwkosakssii = ["\x74\162\x61\x6e\x73\160\157\162\x74" => "\x72\x65\x66\x72\x65\x73\x68", "\143\141\160\x61\x62\x69\154\x69\x74\171" => "\145\144\x69\x74\137\164\x68\x65\155\145\x5f\157\x70\x74\151\157\156\x73", "\x64\145\146\x61\x75\x6c\x74" => $aiowsaccomcoikus->oiswysuiioecsaae(), "\163\141\x6e\151\x74\x69\x7a\x65\x5f\x63\141\154\154\x62\141\143\153" => $aiowsaccomcoikus->ikaukuqokwgsyeia()]; parent::__construct($eygsasmqycagyayw, $aiowsaccomcoikus->mwikyscisascoeea(), $ywmkwiwkosakssii); } public function ygwimyogyaqgumam() : ?Field { return $this->field; } }
