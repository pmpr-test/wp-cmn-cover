<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cffeeccd8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customizer\Segment; class Panel extends Segment { protected ?string $type = "\127\120\137\103\165\163\164\x6f\x6d\151\x7a\145\x5f\120\141\156\x65\154"; protected ?array $sections = []; public function suuogccckocgseyg() : ?array { return $this->sections; } public function kwkugmqouisgkqig(Section $awcmekyiwwkeyisq) : self { $awcmekyiwwkeyisq->ouuceooysqugqmee($this->mwikyscisascoeea()); $this->sections[$awcmekyiwwkeyisq->mwikyscisascoeea()] = $awcmekyiwwkeyisq; return $this; } }
