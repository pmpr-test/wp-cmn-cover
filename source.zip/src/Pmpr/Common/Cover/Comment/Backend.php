<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8503a050             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\x69\164", [$this, "\151\x6e\151\164"]); } public function init() { if (!($this->caokeucsksukesyo()->yagekskwwyqosqcs()->uqwgsuysegkweago() && $this->caokeucsksukesyo()->owicscwgeuqcqaig()->euqowsuwmgokuqqo())) { goto oimkeqocuguqqsqk; } MetaBox::cgygmuguceeosoey("\143\x6f\155\x6d\x65\156\x74\137\165\x73\145\162\137\151\x64", __("\103\157\x6d\x6d\x65\156\164\40\x4d\145\164\141\144\x61\164\x61", PR__CMN__COVER), true)->mkksewyosgeumwsa(MetaBox::ckuwucygcwsiawms(self::wcigqgscaeeqiigq, __("\125\x73\145\x72", PR__CMN__COVER))->soyqkauogoaqekos())->saemoowcasogykak(IconInterface::wqqgoiyyqicsycmm)->gisikkgygmseekyi(); oimkeqocuguqqsqk: } }
