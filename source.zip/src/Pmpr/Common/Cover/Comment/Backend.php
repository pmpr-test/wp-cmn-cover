<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd411ad3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\151\x74", [$this, "\151\156\x69\164"]); } public function init() { if (!($this->caokeucsksukesyo()->yagekskwwyqosqcs()->uqwgsuysegkweago() && $this->caokeucsksukesyo()->owicscwgeuqcqaig()->euqowsuwmgokuqqo())) { goto qicwaskssogcokgm; } MetaBox::cgygmuguceeosoey("\143\157\x6d\x6d\x65\x6e\164\137\x75\163\x65\x72\137\151\x64", __("\x43\x6f\x6d\155\145\x6e\x74\40\x4d\145\164\x61\144\x61\x74\141", PR__CMN__COVER), true)->mkksewyosgeumwsa(MetaBox::ckuwucygcwsiawms(self::wcigqgscaeeqiigq, __("\x55\x73\x65\x72", PR__CMN__COVER))->soyqkauogoaqekos())->saemoowcasogykak(IconInterface::wqqgoiyyqicsycmm)->gisikkgygmseekyi(); qicwaskssogcokgm: } }
