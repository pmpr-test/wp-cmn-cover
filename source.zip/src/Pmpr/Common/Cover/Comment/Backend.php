<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6786e841c4cb2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Backend extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\x6e\x69\x74", [$this, "\x69\156\x69\164"]); } public function init() { if ($this->caokeucsksukesyo()->yagekskwwyqosqcs()->uqwgsuysegkweago() && $this->caokeucsksukesyo()->owicscwgeuqcqaig()->awumyiewiaosiyyy()) { MetaBox::cgygmuguceeosoey("\143\157\155\155\x65\156\164\137\165\x73\x65\x72\x5f\151\x64", __("\103\x6f\x6d\x6d\x65\x6e\164\x20\115\x65\x74\x61\x64\141\x74\x61", PR__CMN__COVER), true)->mkksewyosgeumwsa(MetaBox::ckuwucygcwsiawms(self::wcigqgscaeeqiigq, __("\x55\x73\145\162", PR__CMN__COVER))->soyqkauogoaqekos())->saemoowcasogykak(IconInterface::wqqgoiyyqicsycmm)->gisikkgygmseekyi(); } } }
