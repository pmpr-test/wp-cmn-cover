<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68cc71c800ca9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment\Traits; use Pmpr\Common\Cover\Comment\Mediator; trait CommonTrait { public function msaiieqagyoqqamc($comment) { $ksaameoqigiaoigg = false; if ($comment) { $useksmwkuswkwcqg = Mediator::yomcesuuyoqqgycw; $kuowggqsyksiyygi = $this->caokeucsksukesyo()->yagekskwwyqosqcs(); if ($useksmwkuswkwcqg === $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->gueasuouwqysmomu($kuowggqsyksiyygi->ayueggmoqeeukqmq($comment))) { $ksaameoqigiaoigg = $kuowggqsyksiyygi->igawqaomowicuayw($useksmwkuswkwcqg, $comment); if (!$ksaameoqigiaoigg) { $ksaameoqigiaoigg = $this->msaiieqagyoqqamc($kuowggqsyksiyygi->qqiwsumoyiukmgco($comment)); if ($ksaameoqigiaoigg) { $this->uwkmaywceaaaigwo()->yagekskwwyqosqcs()->ksmqawcowkmegigw($kuowggqsyksiyygi->iooowgsqoyqseyuu($comment), $useksmwkuswkwcqg, $ksaameoqigiaoigg); } } } } return $ksaameoqigiaoigg; } }
