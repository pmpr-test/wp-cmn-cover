<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae189491d0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment\Traits; use Pmpr\Common\Cover\Comment\Mediator; trait CommonTrait { public function msaiieqagyoqqamc($comment) { $ksaameoqigiaoigg = false; if (!$comment) { goto usquiuuyiyqaeyiu; } $useksmwkuswkwcqg = Mediator::yomcesuuyoqqgycw; $kuowggqsyksiyygi = $this->caokeucsksukesyo()->yagekskwwyqosqcs(); if (!($useksmwkuswkwcqg === $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->gueasuouwqysmomu($kuowggqsyksiyygi->ayueggmoqeeukqmq($comment)))) { goto kymkucucyeoeikim; } $ksaameoqigiaoigg = $kuowggqsyksiyygi->igawqaomowicuayw($useksmwkuswkwcqg, $comment); if ($ksaameoqigiaoigg) { goto hoeeyiowekaeemko; } $ksaameoqigiaoigg = $this->msaiieqagyoqqamc($kuowggqsyksiyygi->qqiwsumoyiukmgco($comment)); if (!$ksaameoqigiaoigg) { goto iekumemscwieugqw; } $this->uwkmaywceaaaigwo()->yagekskwwyqosqcs()->ksmqawcowkmegigw($kuowggqsyksiyygi->iooowgsqoyqseyuu($comment), $useksmwkuswkwcqg, $ksaameoqigiaoigg); iekumemscwieugqw: hoeeyiowekaeemko: kymkucucyeoeikim: usquiuuyiyqaeyiu: return $ksaameoqigiaoigg; } }
