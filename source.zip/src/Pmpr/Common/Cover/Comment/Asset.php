<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b083ce992             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\146\157\x72\x65\137\x65\156\x71\165\145\x75\145\x5f\x66\162\157\156\x74\145\x6e\144\137\141\163\163\145\164\x73", [$this, "\145\x6e\x71\x75\145\x75\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\157\x6d\x6d\x65\x6e\x74", $eygsasmqycagyayw->get("\x63\x6f\x6d\155\x65\156\164\x2e\152\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\x6f\155\x6d\145\x6e\164", ["\141\152\x61\170" => Ajax::myikkigscysoykgy]); } } }
