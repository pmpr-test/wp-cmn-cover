<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c383b33e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\Constants; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\x66\x6f\162\145\x5f\x65\156\x71\x75\145\165\145\137\x66\x72\x6f\x6e\x74\x65\x6e\144\137\141\163\x73\145\x74\163", [$this, "\x65\x6e\161\165\145\x75\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, "\143\x6f\155\155\x65\x6e\164", "\143\157\x6d\x6d\145\156\164\56\152\163")->simswskycwagoeqy())->qkqeooqcomucuwyk($this, "\143\157\155\x6d\145\156\x74", [Constants::wyucqaeuuqkesque => Ajax::myikkigscysoykgy]); } } }
