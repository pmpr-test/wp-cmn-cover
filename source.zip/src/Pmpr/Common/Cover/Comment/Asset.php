<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716beac1a112             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\146\157\x72\x65\137\x65\156\x71\165\145\165\145\137\x66\162\x6f\x6e\x74\145\156\x64\137\141\x73\x73\x65\x74\163", [$this, "\x65\156\x71\165\145\165\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\x6f\155\x6d\145\156\164", $eygsasmqycagyayw->get("\x63\x6f\155\155\145\x6e\x74\x2e\x6a\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\x6d\155\x65\156\x74", ["\141\152\x61\x78" => Ajax::myikkigscysoykgy]); } } }
