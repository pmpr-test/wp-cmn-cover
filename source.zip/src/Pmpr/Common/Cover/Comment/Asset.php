<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052cd52d7c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\146\x6f\162\145\x5f\145\x6e\161\x75\145\165\145\137\146\x72\157\156\x74\145\156\x64\x5f\x61\163\x73\145\x74\163", [$this, "\145\x6e\x71\x75\145\165\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\157\155\x6d\145\x6e\164", $eygsasmqycagyayw->get("\x63\157\155\x6d\x65\x6e\164\56\x6a\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\157\155\155\145\x6e\x74", ["\141\x6a\x61\x78" => Ajax::myikkigscysoykgy]); } } }
