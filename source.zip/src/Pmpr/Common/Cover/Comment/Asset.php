<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a7b09bcd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\146\x6f\162\145\137\x65\156\x71\x75\145\x75\x65\137\146\162\157\x6e\164\x65\x6e\x64\x5f\x61\163\163\x65\164\163", [$this, "\x65\156\x71\x75\x65\x75\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\x6f\155\155\145\x6e\164", $eygsasmqycagyayw->get("\x63\x6f\155\155\x65\x6e\164\56\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\157\155\155\145\x6e\x74", ["\141\152\141\x78" => Ajax::myikkigscysoykgy]); } } }
