<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4443ec418             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\x66\x6f\162\145\137\x65\x6e\161\165\x65\165\145\137\x66\162\157\x6e\164\x65\x6e\144\x5f\x61\163\163\x65\164\163", [$this, "\145\156\161\x75\145\x75\145"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\x6f\155\155\x65\156\x74", $eygsasmqycagyayw->get("\143\157\x6d\155\x65\156\164\56\152\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\x6d\155\x65\156\164", ["\141\x6a\141\x78" => Ajax::myikkigscysoykgy]); } } }
