<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d8eb9d924             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\x66\157\162\145\137\145\156\x71\x75\145\x75\145\x5f\146\x72\157\x6e\164\145\x6e\x64\x5f\x61\x73\x73\145\x74\x73", [$this, "\145\x6e\x71\165\x65\165\145"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto mscgewkcqcoowweg; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\x6f\x6d\x6d\x65\x6e\x74", $eygsasmqycagyayw->get("\143\157\x6d\x6d\145\156\x74\56\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\157\x6d\x6d\145\156\x74", ["\x61\x6a\x61\170" => Ajax::myikkigscysoykgy]); mscgewkcqcoowweg: } }
