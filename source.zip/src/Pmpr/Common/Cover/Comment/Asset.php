<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed85a1ef6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\x66\x6f\x72\145\x5f\145\x6e\x71\165\x65\x75\145\x5f\x66\162\x6f\x6e\164\x65\156\x64\x5f\141\163\x73\x65\164\163", [$this, "\x65\156\x71\165\145\x75\145"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\157\x6d\x6d\145\x6e\x74", $eygsasmqycagyayw->get("\x63\x6f\155\155\145\x6e\x74\x2e\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\157\x6d\155\145\x6e\x74", ["\x61\152\141\x78" => Ajax::myikkigscysoykgy]); } } }
