<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67059fda52cde             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\x66\157\x72\x65\137\145\156\x71\165\145\165\x65\137\x66\x72\x6f\x6e\164\145\156\144\x5f\141\163\x73\x65\x74\163", [$this, "\x65\156\161\165\145\165\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\157\155\155\145\x6e\164", $eygsasmqycagyayw->get("\143\157\155\x6d\145\156\x74\56\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\x6f\155\155\145\156\x74", ["\x61\x6a\141\170" => Ajax::myikkigscysoykgy]); } } }
