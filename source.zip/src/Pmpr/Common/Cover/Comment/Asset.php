<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d88946bbc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\146\x6f\162\145\x5f\145\156\x71\x75\x65\x75\x65\x5f\146\x72\157\x6e\x74\x65\156\144\137\141\163\x73\x65\164\163", [$this, "\x65\x6e\161\x75\145\165\145"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\157\x6d\x6d\145\156\164", $eygsasmqycagyayw->get("\143\x6f\155\x6d\x65\156\164\x2e\x6a\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\x6f\x6d\x6d\x65\x6e\164", ["\x61\152\x61\x78" => Ajax::myikkigscysoykgy]); } } }
