<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6cfc9458             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\x66\157\162\145\x5f\x65\156\161\165\145\x75\x65\x5f\146\162\x6f\x6e\x74\x65\x6e\x64\137\x61\163\163\145\x74\163", [$this, "\x65\x6e\161\x75\x65\x75\145"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto suqcsgaosywaauuu; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\x6f\x6d\x6d\145\x6e\x74", $eygsasmqycagyayw->get("\x63\x6f\155\155\145\156\164\56\152\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\x6f\x6d\x6d\145\156\164", ["\x61\152\x61\x78" => Ajax::myikkigscysoykgy]); suqcsgaosywaauuu: } }
