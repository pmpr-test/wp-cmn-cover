<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6bc133b1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\Constants; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\146\157\162\x65\137\145\156\x71\x75\145\165\145\x5f\146\162\157\156\164\145\156\x64\x5f\x61\163\163\x65\x74\163", [$this, "\x65\156\161\165\145\x75\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, "\143\x6f\x6d\155\145\x6e\164", "\143\157\x6d\155\x65\156\x74\56\x6a\163")->simswskycwagoeqy())->qkqeooqcomucuwyk($this, "\143\x6f\155\155\145\156\x74", [Constants::wyucqaeuuqkesque => Ajax::myikkigscysoykgy]); } } }
