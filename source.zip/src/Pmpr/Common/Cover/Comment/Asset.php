<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd804d337             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\Constants; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\146\157\162\145\137\x65\156\161\165\x65\x75\x65\137\146\x72\x6f\x6e\164\x65\x6e\144\x5f\141\x73\x73\145\x74\163", [$this, "\145\156\x71\x75\145\x75\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, "\x63\x6f\155\x6d\145\156\164", "\143\157\x6d\x6d\145\x6e\164\56\152\163")->simswskycwagoeqy())->qkqeooqcomucuwyk($this, "\143\x6f\x6d\155\145\x6e\164", [Constants::wyucqaeuuqkesque => Ajax::myikkigscysoykgy]); } } }
