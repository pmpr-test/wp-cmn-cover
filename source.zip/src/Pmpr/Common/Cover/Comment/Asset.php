<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             674458708a1bd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\Constants; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\146\157\162\x65\x5f\x65\156\x71\x75\x65\x75\x65\x5f\x66\x72\157\156\164\x65\156\x64\137\x61\163\163\x65\x74\163", [$this, "\145\x6e\161\x75\145\165\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, "\x63\x6f\155\155\145\x6e\164", "\x63\x6f\155\x6d\145\156\x74\56\152\x73")->simswskycwagoeqy())->qkqeooqcomucuwyk($this, "\143\x6f\155\155\145\x6e\x74", [Constants::wyucqaeuuqkesque => Ajax::myikkigscysoykgy]); } } }
