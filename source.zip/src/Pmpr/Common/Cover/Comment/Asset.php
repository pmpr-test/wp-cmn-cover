<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7677fb1d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\x66\x6f\162\x65\x5f\145\156\161\165\x65\165\x65\x5f\x66\x72\157\x6e\x74\145\x6e\144\137\141\163\x73\x65\x74\x73", [$this, "\x65\156\161\x75\145\165\145"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto mswsoaimesegiiic; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\x6f\x6d\x6d\145\x6e\x74", $eygsasmqycagyayw->get("\x63\157\x6d\155\x65\156\x74\x2e\152\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\x6f\155\x6d\x65\156\164", ["\x61\x6a\x61\170" => Ajax::myikkigscysoykgy]); mswsoaimesegiiic: } }
