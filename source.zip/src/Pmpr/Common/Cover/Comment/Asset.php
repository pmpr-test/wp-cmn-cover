<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb3b365c59             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\x66\x6f\162\x65\137\145\x6e\161\x75\145\x75\145\137\x66\x72\x6f\156\164\145\x6e\144\x5f\x61\x73\163\x65\164\163", [$this, "\x65\156\x71\x75\145\165\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto suqcsgaosywaauuu; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\143\x6f\155\155\x65\156\164", $eygsasmqycagyayw->get("\143\157\x6d\x6d\x65\x6e\x74\x2e\152\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\x6f\155\155\x65\156\164", ["\141\x6a\x61\170" => Ajax::myikkigscysoykgy]); suqcsgaosywaauuu: } }
