<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd411ad3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\x66\157\162\x65\137\x65\156\161\x75\145\x75\x65\x5f\x66\162\157\156\164\145\x6e\144\x5f\141\163\x73\x65\164\163", [$this, "\145\x6e\161\x75\x65\x75\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto mswsoaimesegiiic; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\x6f\x6d\155\145\156\x74", $eygsasmqycagyayw->get("\x63\x6f\155\x6d\145\x6e\x74\56\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\155\155\145\x6e\164", ["\141\152\x61\x78" => Ajax::myikkigscysoykgy]); mswsoaimesegiiic: } }
