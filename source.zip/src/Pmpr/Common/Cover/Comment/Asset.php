<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb4132b7d7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\146\157\162\x65\x5f\145\x6e\x71\165\145\x75\145\137\x66\162\x6f\156\x74\x65\x6e\x64\137\x61\x73\x73\145\x74\163", [$this, "\145\x6e\161\x75\145\x75\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto suqcsgaosywaauuu; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\x6f\x6d\x6d\x65\156\164", $eygsasmqycagyayw->get("\143\x6f\155\x6d\145\x6e\x74\56\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\x6f\155\155\x65\x6e\x74", ["\x61\x6a\x61\x78" => Ajax::myikkigscysoykgy]); suqcsgaosywaauuu: } }
