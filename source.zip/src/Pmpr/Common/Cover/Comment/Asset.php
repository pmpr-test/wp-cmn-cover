<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705a35c717bc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\x65\x66\157\x72\145\x5f\x65\x6e\x71\x75\145\x75\x65\x5f\146\x72\157\156\164\145\156\x64\x5f\141\163\x73\x65\164\163", [$this, "\145\x6e\x71\165\x65\165\145"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\x6f\155\x6d\145\156\164", $eygsasmqycagyayw->get("\x63\x6f\155\155\x65\x6e\164\x2e\x6a\x73"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\x63\157\155\155\145\156\x74", ["\141\152\x61\170" => Ajax::myikkigscysoykgy]); } } }
