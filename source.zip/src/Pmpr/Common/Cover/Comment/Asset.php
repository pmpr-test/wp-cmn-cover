<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             674459939f07b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\Constants; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\145\146\x6f\x72\x65\137\x65\x6e\x71\165\x65\x75\145\x5f\146\x72\157\x6e\164\x65\156\x64\137\141\x73\163\145\x74\x73", [$this, "\x65\x6e\161\165\145\165\145"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, "\143\x6f\155\x6d\x65\156\164", "\143\x6f\x6d\x6d\x65\156\164\56\x6a\x73")->simswskycwagoeqy())->qkqeooqcomucuwyk($this, "\x63\157\155\155\145\x6e\x74", [Constants::wyucqaeuuqkesque => Ajax::myikkigscysoykgy]); } } }
