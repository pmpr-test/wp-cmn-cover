<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc05648ef2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; use Pmpr\Common\Foundation\Interfaces\Constants; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\142\x65\146\157\x72\x65\x5f\145\x6e\161\x75\x65\x75\x65\x5f\x66\x72\x6f\156\164\145\x6e\x64\137\x61\x73\163\x65\164\163", [$this, "\x65\x6e\x71\x75\x65\x75\x65"]); } public function enqueue() { if ($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka()) { $meakksicouekcgoe = $this->caokeucsksukesyo()->usugyumcgeaaowsi(); $meakksicouekcgoe->yawoscugkyysowie($meakksicouekcgoe->owygwqwawqoiusis($this, "\x63\157\x6d\x6d\x65\156\x74", "\x63\x6f\x6d\155\x65\156\164\x2e\152\163")->simswskycwagoeqy())->qkqeooqcomucuwyk($this, "\143\x6f\x6d\155\x65\156\x74", [Constants::wyucqaeuuqkesque => Ajax::myikkigscysoykgy]); } } }
