<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d87913155             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Asset extends Common { public function wigskegsqequoeks() { $this->waqewsckuayqguos("\x62\145\x66\157\x72\x65\137\145\x6e\161\165\x65\x75\145\x5f\146\162\x6f\x6e\164\145\156\x64\x5f\141\163\163\145\x74\163", [$this, "\x65\156\x71\165\145\165\x65"]); } public function enqueue() { if (!($this->kuqogciwkswmckgw() && $this->uiqcwsowwswommka())) { goto mscgewkcqcoowweg; } $eygsasmqycagyayw = $this->miocmcoykayoyyau(); $eygsasmqycagyayw->oeoquuwkoywiuesy($eygsasmqycagyayw->owygwqwawqoiusis("\x63\157\x6d\x6d\x65\156\x74", $eygsasmqycagyayw->get("\143\157\155\155\x65\156\x74\56\152\163"))->simswskycwagoeqy()); $eygsasmqycagyayw->ieayqiyiuuguowyq("\143\x6f\155\155\x65\x6e\x74", ["\x61\152\141\170" => Ajax::myikkigscysoykgy]); mscgewkcqcoowweg: } }
