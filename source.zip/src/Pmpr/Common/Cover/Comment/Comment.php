<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7677fb1d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto eiawsoasmscmqswa; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto ickcmqoiosquugwe; eiawsoasmscmqswa: Backend::symcgieuakksimmu(); ickcmqoiosquugwe: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\164", [$this, "\x69\x6e\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\163\137\x61\x6c\154\157\167\x5f\162\145\156\144\145\162", [$this, "\165\x69\x71\x63\x77\x73\x6f\167\167\x73\167\x6f\x6d\155\x6b\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
