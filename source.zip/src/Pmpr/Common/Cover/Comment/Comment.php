<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6cfc9458             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto qikaewekoecykeou; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto eucqomyqykgoiuge; qikaewekoecykeou: Backend::symcgieuakksimmu(); eucqomyqykgoiuge: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\x69\x74", [$this, "\x69\156\151\164"], 0); } public function init() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto usymasgsyqgsuocg; } Setting::symcgieuakksimmu(); usymasgsyqgsuocg: } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\151\x73\x5f\x61\154\154\157\167\137\162\x65\x6e\144\x65\x72", [$this, "\165\151\x71\x63\167\x73\157\x77\x77\163\167\x6f\155\x6d\153\141"]); } }
