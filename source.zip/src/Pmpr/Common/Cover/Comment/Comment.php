<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d87913155             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto yqagomygmeoecwey; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto qikaewekoecykeou; yqagomygmeoecwey: Backend::symcgieuakksimmu(); qikaewekoecykeou: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\x74", [$this, "\151\156\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\x5f\x61\154\x6c\157\x77\137\162\145\x6e\x64\145\162", [$this, "\165\x69\x71\143\167\x73\x6f\x77\167\163\x77\157\x6d\155\153\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
