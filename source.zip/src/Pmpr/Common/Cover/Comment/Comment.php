<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd411ad3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto eiawsoasmscmqswa; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto ickcmqoiosquugwe; eiawsoasmscmqswa: Backend::symcgieuakksimmu(); ickcmqoiosquugwe: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\x6e\x69\x74", [$this, "\x69\x6e\151\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\137\x61\x6c\154\157\x77\137\x72\145\x6e\144\x65\162", [$this, "\x75\151\x71\143\167\x73\157\167\167\x73\167\157\x6d\x6d\x6b\x61"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
