<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522cf24bc52             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->awumyiewiaosiyyy()) { Backend::symcgieuakksimmu(); } else { Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); } } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\151\x74", [$this, "\151\156\x69\x74"], 0); } public function init() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { Setting::symcgieuakksimmu(); } } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\x5f\x61\154\154\x6f\x77\137\x72\145\x6e\144\x65\162", [$this, "\165\151\161\143\167\x73\x6f\167\x77\x73\x77\157\155\155\x6b\x61"]); } }
