<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4ad59a55             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->awumyiewiaosiyyy()) { Backend::symcgieuakksimmu(); } else { Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); } } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\x6e\151\164", [$this, "\x69\x6e\151\x74"], 0); } public function init() { if ($this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { Setting::symcgieuakksimmu(); } } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\x73\x5f\x61\x6c\154\157\167\137\162\x65\x6e\x64\x65\162", [$this, "\x75\151\x71\x63\x77\163\x6f\167\x77\x73\x77\157\155\x6d\x6b\141"]); } }
