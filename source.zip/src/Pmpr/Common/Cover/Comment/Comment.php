<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d8eb9d924             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto yqagomygmeoecwey; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto qikaewekoecykeou; yqagomygmeoecwey: Backend::symcgieuakksimmu(); qikaewekoecykeou: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\151\x74", [$this, "\x69\x6e\x69\x74"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\x5f\x61\154\154\x6f\167\137\x72\x65\x6e\x64\x65\162", [$this, "\165\x69\161\143\167\163\157\167\x77\x73\x77\157\x6d\155\x6b\141"]); } public function init() { SettingSection::symcgieuakksimmu(); } }
