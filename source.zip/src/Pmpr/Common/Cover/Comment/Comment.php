<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517377ff95             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Comment; class Comment extends Common { public function mameiwsayuyquoeq() { Mediator::symcgieuakksimmu(); $owaoeyikmqaeegma = $this->caokeucsksukesyo()->owicscwgeuqcqaig(); if ($owaoeyikmqaeegma->euqowsuwmgokuqqo()) { goto yqagomygmeoecwey; } Form::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); goto qikaewekoecykeou; yqagomygmeoecwey: Backend::symcgieuakksimmu(); qikaewekoecykeou: } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\151\156\x69\x74", [$this, "\151\156\x69\x74"], 0); } public function init() { if (!$this->uwkmaywceaaaigwo()->owicscwgeuqcqaig()->goecwaaykqoaaagg()) { goto eucqomyqykgoiuge; } Setting::symcgieuakksimmu(); eucqomyqykgoiuge: } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ukyommesgeqqcayq . "\x69\163\137\x61\154\x6c\157\x77\137\162\x65\156\x64\145\x72", [$this, "\165\x69\x71\x63\x77\x73\x6f\x77\167\x73\x77\157\155\x6d\153\x61"]); } }
