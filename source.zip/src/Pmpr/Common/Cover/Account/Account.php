<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68dda3c458a4e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Account; use Pmpr\Common\Cover\Container; class Account extends Container { }
