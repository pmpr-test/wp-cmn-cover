<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67e934c577f87             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Account; use Pmpr\Common\Cover\Container; class Account extends Container { }
