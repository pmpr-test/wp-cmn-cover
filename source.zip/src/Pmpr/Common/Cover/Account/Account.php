<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             674459939f07b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Account; use Pmpr\Common\Cover\Container; class Account extends Container { }
