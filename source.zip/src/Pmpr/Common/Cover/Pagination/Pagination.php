<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             692c4c318f585             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Pagination; use Pmpr\Common\Cover\Container; class Pagination extends Container { public function mameiwsayuyquoeq() { Post::symcgieuakksimmu(); Custom::symcgieuakksimmu(); Comment::symcgieuakksimmu(); } }
