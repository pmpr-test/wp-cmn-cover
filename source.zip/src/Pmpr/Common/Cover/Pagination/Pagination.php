<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4ad59a55             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Pagination; use Pmpr\Common\Cover\Container; class Pagination extends Container { public function mameiwsayuyquoeq() { Post::symcgieuakksimmu(); Custom::symcgieuakksimmu(); Comment::symcgieuakksimmu(); } }
