<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d88946bbc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\Setting\Section; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Setting extends Section { const iukiayaokaiiicwo = "\x62\162\145\x61\144\x63\x72\x75\x6d\142\x5f"; const mgimioakqsosoqcc = self::iukiayaokaiiicwo . Constants::iccwcygaeqmomooo; const gsqueoqmwgwgykuy = self::iukiayaokaiiicwo . Constants::qgiwmgmeaagqwgkw; public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\142\162\x65\x61\x64\143\162\165\155\x62")->gswweykyogmsyawy(__("\x42\x72\x65\141\144\x63\x72\x75\155\142", PR__CMN__COVER))->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::mgimioakqsosoqcc)->gswweykyogmsyawy(__("\x44\x69\x73\x70\154\141\x79\x20\x42\x72\x65\x61\x64\x63\162\x75\155\142", PR__CMN__COVER)))->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::gsqueoqmwgwgykuy)->gswweykyogmsyawy(__("\105\x78\143\x6c\x75\144\x65\40\120\x6f\x73\x74\x73", PR__CMN__COVER))->ukqywcsoogkyoaoa()->oikgogcweiiaocka()->mkmssscwmeekwgqo())->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->jyumyyugiwwiqomk(100)); } }
