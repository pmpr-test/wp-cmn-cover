<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052cd52d7c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\Setting\Section; use Pmpr\Common\Foundation\Interfaces\Constants; use Pmpr\Common\Foundation\Interfaces\IconInterface; class Setting extends Section { const iukiayaokaiiicwo = "\x62\162\x65\141\x64\x63\162\165\155\142\137"; const mgimioakqsosoqcc = self::iukiayaokaiiicwo . Constants::iccwcygaeqmomooo; const gsqueoqmwgwgykuy = self::iukiayaokaiiicwo . Constants::qgiwmgmeaagqwgkw; public function ykwqaukkycogooii() { $this->kwkugmqouisgkqig($this->ycgeeoiieoiakgam("\x62\162\x65\141\x64\143\x72\165\155\x62")->gswweykyogmsyawy(__("\102\162\x65\x61\x64\x63\162\x75\x6d\142", PR__CMN__COVER))->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->mkksewyosgeumwsa($this->wcwmusaouiqaqeww(self::mgimioakqsosoqcc)->gswweykyogmsyawy(__("\104\x69\x73\x70\154\141\171\x20\102\162\145\141\144\x63\162\165\155\142", PR__CMN__COVER)))->mkksewyosgeumwsa($this->mccagaqeagiikkec(self::gsqueoqmwgwgykuy)->gswweykyogmsyawy(__("\105\170\x63\154\165\144\145\x20\120\157\163\x74\163", PR__CMN__COVER))->ukqywcsoogkyoaoa()->oikgogcweiiaocka()->mkmssscwmeekwgqo())->saemoowcasogykak(IconInterface::qggkwmcgqagcouci)->jyumyyugiwwiqomk(100)); } }
