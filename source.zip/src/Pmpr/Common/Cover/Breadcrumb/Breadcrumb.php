<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7677fb1d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Breadcrumb extends Common { public function mameiwsayuyquoeq() { Frontend::symcgieuakksimmu(); } public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x69\156\x69\x74", [$this, "\151\x6e\x69\164"], 0); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\x65\164\x5f\x69\x74\145\x6d\x73", [$this, "\167\x61\x73\147\x77\163\157\147\x6d\x75\161\x75\161\x65\x61\141"], 10, 2); } public function init() { SettingSection::symcgieuakksimmu(); } public function aqyikqugcomoqqqi() { if (!$this->omseesogaocascyo("\x73\x74\x72\x75\143\164\x75\x72\x65\x64\55\144\141\x74\141")) { goto uqokiksoqcwwqgio; } StructuredData::symcgieuakksimmu(); uqokiksoqcwwqgio: } public function wasgwsogmuquqeaa(array $oammesyieqmwuwyi = [], array $ywmkwiwkosakssii = []) : array { if (!($this->uiqcwsowwswommka() && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto qukocuwgakemmyga; } $eaekkwggowaaogiu->create($ywmkwiwkosakssii); $oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi(); qukocuwgakemmyga: return $oammesyieqmwuwyi; } }
