<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517377ff95             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; class Breadcrumb extends Common { public function mameiwsayuyquoeq() { Frontend::symcgieuakksimmu(); } public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\145\164\x5f\151\164\145\x6d\163", [$this, "\167\141\163\x67\x77\x73\157\x67\x6d\165\161\165\x71\145\141\x61"], 10, 2); } public function aqyikqugcomoqqqi() { if (!$this->caokeucsksukesyo()->cqusmgskowmesgcg()->iqqgmieeqemiowuk("\163\164\x72\165\x63\x74\x75\162\x65\144\x2d\144\141\x74\141")) { goto koggssokukoukkay; } StructuredData::symcgieuakksimmu(); koggssokukoukkay: } public function wasgwsogmuquqeaa(array $oammesyieqmwuwyi = [], array $ywmkwiwkosakssii = []) : array { if (!($this->uiqcwsowwswommka() && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto ueaiskyiqcquiika; } $eaekkwggowaaogiu->create($ywmkwiwkosakssii); $oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi(); ueaiskyiqcquiika: return $oammesyieqmwuwyi; } }
