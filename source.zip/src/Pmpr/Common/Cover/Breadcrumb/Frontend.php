<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb3b365c59             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\156\x64\145\162", [$this, "\162\x65\156\144\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\164\x5f\150\x74\155\154", [$this, "\167\x67\161\161\147\145\167\x63\x6d\143\x65\155\157\145\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto gwoacimkeyymqccq; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto wiqigqgiegmacgsw; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; wiqigqgiegmacgsw: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\156\x64\145\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); gwoacimkeyymqccq: return $oqweiggykuywsyas; } }
