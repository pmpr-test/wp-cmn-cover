<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d87913155             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\x65\x6e\x64\145\162", [$this, "\x72\145\x6e\144\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\164\x5f\x68\164\x6d\154", [$this, "\x77\x67\161\x71\x67\x65\167\143\x6d\143\x65\155\x6f\145\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto aymmymequcisekie; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto yyamycyesguwueuw; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; yyamycyesguwueuw: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\156\x64\x65\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); aymmymequcisekie: return $oqweiggykuywsyas; } }
