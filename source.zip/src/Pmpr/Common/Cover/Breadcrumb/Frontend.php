<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd411ad3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\x65\x6e\x64\145\162", [$this, "\162\145\156\x64\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\164\x5f\x68\x74\155\154", [$this, "\167\147\x71\x71\x67\x65\x77\x63\155\x63\145\155\157\145\x77\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto uqqaiagaeqgqgaiy; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto uguigkcmukuouway; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; uguigkcmukuouway: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\156\144\145\170", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); uqqaiagaeqgqgaiy: return $oqweiggykuywsyas; } }
