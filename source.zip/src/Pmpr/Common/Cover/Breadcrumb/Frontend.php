<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6cfc9458             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\x6e\x64\145\162", [$this, "\x72\145\x6e\144\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\145\164\137\x68\x74\x6d\154", [$this, "\x77\147\161\x71\x67\x65\x77\x63\x6d\143\x65\x6d\157\145\167\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto ssmgmiuqoeiuacsa; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto cqkuuyouqoqyguus; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; cqkuuyouqoqyguus: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\156\x64\145\170", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); ssmgmiuqoeiuacsa: return $oqweiggykuywsyas; } }
