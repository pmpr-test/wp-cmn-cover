<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb4132b7d7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\x65\156\x64\x65\162", [$this, "\162\x65\x6e\x64\x65\x72"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x67\145\x74\x5f\150\164\x6d\x6c", [$this, "\167\x67\x71\x71\147\x65\167\x63\x6d\143\x65\155\157\x65\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto gwoacimkeyymqccq; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto wiqigqgiegmacgsw; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; wiqigqgiegmacgsw: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\x6e\144\x65\170", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); gwoacimkeyymqccq: return $oqweiggykuywsyas; } }
