<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             674458708a1bd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\156\144\145\x72", [$this, "\162\x65\x6e\x64\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\x74\137\150\x74\x6d\x6c", [$this, "\x77\147\161\x71\147\x65\x77\143\155\x63\145\155\x6f\145\x77\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if ($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu())) { $ywmkwiwkosakssii = []; if ($mksyucucyswaukig) { $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; } $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\156\144\x65\170", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); } return $oqweiggykuywsyas; } }
