<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae189491d0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\x65\156\144\x65\162", [$this, "\162\145\x6e\x64\145\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\164\137\x68\x74\x6d\x6c", [$this, "\x77\x67\161\x71\147\145\x77\143\155\143\x65\x6d\x6f\145\167\x6f"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto uqqaiagaeqgqgaiy; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto uguigkcmukuouway; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; uguigkcmukuouway: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\156\x64\145\170", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); uqqaiagaeqgqgaiy: return $oqweiggykuywsyas; } }
