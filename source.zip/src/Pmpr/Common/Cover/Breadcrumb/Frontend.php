<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517377ff95             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\x72\145\156\x64\x65\162", [$this, "\162\x65\x6e\144\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\x74\137\x68\164\x6d\x6c", [$this, "\167\x67\x71\161\x67\x65\167\x63\x6d\x63\145\155\x6f\x65\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto ssmgmiuqoeiuacsa; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto cqkuuyouqoqyguus; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; cqkuuyouqoqyguus: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\x6e\x64\x65\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); ssmgmiuqoeiuacsa: return $oqweiggykuywsyas; } }
