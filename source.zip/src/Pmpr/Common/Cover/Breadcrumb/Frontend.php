<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68078071256b2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . 'render', [$this, 'render'])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . 'get_html', [$this, 'wgqqgewcmcemoewo'], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if ($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu())) { $ywmkwiwkosakssii = []; if ($mksyucucyswaukig) { $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; } $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw('index', [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); } return $oqweiggykuywsyas; } }
