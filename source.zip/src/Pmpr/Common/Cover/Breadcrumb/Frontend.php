<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8503a050             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\x6e\144\145\162", [$this, "\x72\x65\x6e\144\x65\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\x65\x74\137\150\164\x6d\154", [$this, "\x77\147\x71\x71\x67\x65\x77\143\155\143\145\155\x6f\145\x77\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto aymmymequcisekie; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto yyamycyesguwueuw; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; yyamycyesguwueuw: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\x69\156\144\x65\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); aymmymequcisekie: return $oqweiggykuywsyas; } }
