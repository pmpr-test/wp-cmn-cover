<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d8eb9d924             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Foundation\Interfaces\Constants; class Frontend extends Common { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\162\145\156\x64\x65\x72", [$this, "\162\x65\x6e\144\145\162"])->aqaqisyssqeomwom(self::iukiayaokaiiicwo . "\147\145\164\137\150\x74\x6d\x6c", [$this, "\x77\147\161\x71\x67\145\167\x63\x6d\143\145\x6d\157\x65\167\157"], 10, 2); } public function render($mksyucucyswaukig) { echo $this->wgqqgewcmcemoewo('', $mksyucucyswaukig); } public function wgqqgewcmcemoewo($oqweiggykuywsyas, $mksyucucyswaukig = null) : string { if (!($this->uiqcwsowwswommka($mksyucucyswaukig) && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()))) { goto aymmymequcisekie; } $ywmkwiwkosakssii = []; if (!$mksyucucyswaukig) { goto yyamycyesguwueuw; } $ywmkwiwkosakssii[Constants::ckmqoekmugkggeym] = $mksyucucyswaukig; yyamycyesguwueuw: $ewgwqamkygiqaawc = $eaekkwggowaaogiu->generate($ywmkwiwkosakssii); $oqweiggykuywsyas = $this->iuygowkemiiwqmiw("\151\156\x64\x65\x78", [Constants::ssmskyqgcmeiayco => $ewgwqamkygiqaawc]); aymmymequcisekie: return $oqweiggykuywsyas; } }
