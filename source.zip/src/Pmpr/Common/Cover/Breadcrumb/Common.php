<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6cfc9458             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\Container; use Pmpr\Common\Cover\Setting\Setting as BaseSetting; abstract class Common extends Container { const iukiayaokaiiicwo = "\142\162\145\x61\x64\143\162\x75\x6d\x62\137"; const ggcmgaccygaquiwu = self::iukiayaokaiiicwo . "\142\x65\x66\x6f\x72\x65\x5f\x63\x72\145\x61\164\145\x5f"; public function uiqcwsowwswommka($post = null) : bool { $cuakwceieagskoaa = false; if (!BaseSetting::eiwcuqigayigimak(Setting::mgimioakqsosoqcc)) { goto gwoacimkeyymqccq; } $cuakwceieagskoaa = true; if (!($post = (string) $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->iooowgsqoyqseyuu($post))) { goto wiqigqgiegmacgsw; } $couiucmsqaieciue = BaseSetting::eiwcuqigayigimak(Setting::gsqueoqmwgwgykuy, []); $cuakwceieagskoaa = !in_array($post, $couiucmsqaieciue, true); wiqigqgiegmacgsw: $cuakwceieagskoaa = $this->ocksiywmkyaqseou(self::iukiayaokaiiicwo . "\x61\x6c\154\157\167\x5f\x72\145\x6e\x64\x65\162", $cuakwceieagskoaa, $post); gwoacimkeyymqccq: return $cuakwceieagskoaa; } }
