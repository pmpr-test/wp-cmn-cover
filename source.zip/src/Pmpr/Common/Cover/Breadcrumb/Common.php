<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb3b365c59             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\Container; use Pmpr\Common\Cover\Setting\Setting as BaseSetting; abstract class Common extends Container { const iukiayaokaiiicwo = "\142\x72\x65\x61\x64\143\162\165\x6d\142\x5f"; const ggcmgaccygaquiwu = self::iukiayaokaiiicwo . "\x62\x65\146\157\x72\145\137\143\162\145\141\x74\x65\137"; public function uiqcwsowwswommka($post = null) : bool { $cuakwceieagskoaa = false; if (!BaseSetting::eiwcuqigayigimak(Setting::mgimioakqsosoqcc)) { goto ueaiskyiqcquiika; } $cuakwceieagskoaa = true; if (!($post = (string) $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->iooowgsqoyqseyuu($post))) { goto koggssokukoukkay; } $couiucmsqaieciue = BaseSetting::eiwcuqigayigimak(Setting::gsqueoqmwgwgykuy, []); $cuakwceieagskoaa = !in_array($post, $couiucmsqaieciue, true); koggssokukoukkay: $cuakwceieagskoaa = $this->ocksiywmkyaqseou(self::iukiayaokaiiicwo . "\141\x6c\154\157\x77\x5f\162\145\156\x64\145\x72", $cuakwceieagskoaa, $post); ueaiskyiqcquiika: return $cuakwceieagskoaa; } }
