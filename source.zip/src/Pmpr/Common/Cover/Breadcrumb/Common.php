<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd66b1d253             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\Container; use Pmpr\Common\Cover\Setting\Setting as BaseSetting; abstract class Common extends Container { const iukiayaokaiiicwo = "\142\x72\145\141\144\143\x72\x75\x6d\x62\137"; const ggcmgaccygaquiwu = self::iukiayaokaiiicwo . "\142\x65\146\x6f\x72\145\x5f\x63\x72\x65\x61\164\145\x5f"; public function uiqcwsowwswommka($post = null) : bool { $cuakwceieagskoaa = false; if (!BaseSetting::eiwcuqigayigimak(Setting::mgimioakqsosoqcc)) { goto gwoacimkeyymqccq; } $cuakwceieagskoaa = true; if (!($post = (string) $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->iooowgsqoyqseyuu($post))) { goto wiqigqgiegmacgsw; } $couiucmsqaieciue = BaseSetting::eiwcuqigayigimak(Setting::gsqueoqmwgwgykuy, []); $cuakwceieagskoaa = !in_array($post, $couiucmsqaieciue, true); wiqigqgiegmacgsw: $cuakwceieagskoaa = $this->ocksiywmkyaqseou(self::iukiayaokaiiicwo . "\141\154\x6c\157\x77\x5f\x72\x65\156\144\145\x72", $cuakwceieagskoaa, $post); gwoacimkeyymqccq: return $cuakwceieagskoaa; } }
