<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a7b09bcd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\Container; abstract class Common extends Container { const iukiayaokaiiicwo = "\x62\x72\x65\x61\144\143\x72\x75\x6d\x62\137"; const ggcmgaccygaquiwu = self::iukiayaokaiiicwo . "\142\145\x66\157\x72\145\x5f\143\162\145\x61\x74\x65\x5f"; public function uiqcwsowwswommka($post = null) : bool { $cuakwceieagskoaa = false; if ($this->weysguygiseoukqw(Setting::mgimioakqsosoqcc)) { $cuakwceieagskoaa = true; if ($post = (string) $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->iooowgsqoyqseyuu($post)) { $couiucmsqaieciue = $this->weysguygiseoukqw(Setting::gsqueoqmwgwgykuy, []); $cuakwceieagskoaa = !in_array($post, $couiucmsqaieciue, true); } $cuakwceieagskoaa = $this->ocksiywmkyaqseou(self::iukiayaokaiiicwo . "\x61\154\x6c\157\x77\x5f\162\x65\x6e\144\x65\162", $cuakwceieagskoaa, $post); } return $cuakwceieagskoaa; } }
