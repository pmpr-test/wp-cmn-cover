<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6786e841c4cb2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Common\Cover\Container; abstract class Common extends Container { const iukiayaokaiiicwo = "\142\x72\145\141\x64\x63\x72\165\x6d\142\x5f"; const ggcmgaccygaquiwu = self::iukiayaokaiiicwo . "\142\x65\x66\x6f\x72\x65\x5f\143\162\145\x61\164\x65\x5f"; public function uiqcwsowwswommka($post = null) : bool { $cuakwceieagskoaa = false; if ($this->weysguygiseoukqw(Setting::mgimioakqsosoqcc)) { $cuakwceieagskoaa = true; if ($post = (string) $this->caokeucsksukesyo()->ayueggmoqeeukqmq()->iooowgsqoyqseyuu($post)) { $couiucmsqaieciue = $this->weysguygiseoukqw(Setting::gsqueoqmwgwgykuy, []); $cuakwceieagskoaa = !in_array($post, $couiucmsqaieciue, true); } $cuakwceieagskoaa = $this->ocksiywmkyaqseou(self::iukiayaokaiiicwo . "\x61\154\154\x6f\x77\x5f\x72\145\x6e\144\145\162", $cuakwceieagskoaa, $post); } return $cuakwceieagskoaa; } }
