<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46a139fd0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage\WebPage; use Pmpr\Module\StructuredData\Schema\Intangible\ItemList\BreadcrumbList; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\145\146\157\162\145\137\x72\145\156\144\x65\162\x5f\x77\x65\142\x70\141\x67\x65\x5f\163\143\x68\x65\x6d\141", [$this, "\167\x69\x77\151\x6f\x75\171\x65\x67\151\161\167\x79\157\163\x73"]); } public function wiwiouyegiqwyoss($mooimoaemiymkucu) { if ($mooimoaemiymkucu instanceof WebPage && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()) && $eaekkwggowaaogiu->uiqcwsowwswommka()) { $eaekkwggowaaogiu->create(); if ($oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi()) { $mooimoaemiymkucu->kmsouiywgsysyogm(new BreadcrumbList($oammesyieqmwuwyi)); } } return $mooimoaemiymkucu; } }
