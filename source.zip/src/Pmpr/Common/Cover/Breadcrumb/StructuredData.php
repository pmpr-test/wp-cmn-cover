<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d88946bbc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage\WebPage; use Pmpr\Module\StructuredData\Schema\Intangible\ItemList\BreadcrumbList; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\142\145\146\157\x72\145\x5f\162\x65\156\144\145\162\137\x77\145\x62\160\141\147\x65\x5f\x73\143\x68\x65\x6d\141", [$this, "\x77\151\x77\x69\x6f\165\x79\145\x67\x69\x71\x77\171\x6f\x73\163"]); } public function wiwiouyegiqwyoss($mooimoaemiymkucu) { if ($mooimoaemiymkucu instanceof WebPage && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()) && $eaekkwggowaaogiu->uiqcwsowwswommka()) { $eaekkwggowaaogiu->create(); if ($oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi()) { $mooimoaemiymkucu->kmsouiywgsysyogm(new BreadcrumbList($oammesyieqmwuwyi)); } } return $mooimoaemiymkucu; } }
