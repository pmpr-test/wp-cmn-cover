<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1cf64db5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Breadcrumb; use Pmpr\Module\StructuredData\AbstractStructuredData; use Pmpr\Module\StructuredData\Schema\CreativeWork\WebPage\WebPage; use Pmpr\Module\StructuredData\Schema\Intangible\ItemList\BreadcrumbList; class StructuredData extends AbstractStructuredData { public function kgquecmsgcouyaya() { $this->aqaqisyssqeomwom(self::ocmiuacywmgycowk . "\x62\x65\x66\157\x72\x65\137\x72\x65\x6e\x64\x65\162\x5f\x77\x65\x62\160\141\x67\145\x5f\163\x63\x68\x65\155\141", [$this, "\x77\x69\x77\151\x6f\165\171\x65\147\151\161\167\x79\157\x73\163"]); } public function wiwiouyegiqwyoss($mooimoaemiymkucu) { if ($mooimoaemiymkucu instanceof WebPage && ($eaekkwggowaaogiu = Generator::symcgieuakksimmu()) && $eaekkwggowaaogiu->uiqcwsowwswommka()) { $eaekkwggowaaogiu->create(); if ($oammesyieqmwuwyi = $eaekkwggowaaogiu->ecwoamckysyqikqi()) { $mooimoaemiymkucu->kmsouiywgsysyogm(new BreadcrumbList($oammesyieqmwuwyi)); } } return $mooimoaemiymkucu; } }
