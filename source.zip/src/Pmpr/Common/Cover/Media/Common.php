<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6cfc9458             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Media; use Pmpr\Common\Cover\Container; abstract class Common extends Container { }
