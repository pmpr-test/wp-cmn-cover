<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67d9d3e8e0add             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Search; class Search extends Common { public function mameiwsayuyquoeq() { Query::symcgieuakksimmu(); Frontend::symcgieuakksimmu(); } }
