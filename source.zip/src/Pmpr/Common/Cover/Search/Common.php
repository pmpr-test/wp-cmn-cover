<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6807a4ab07869             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Search; use Pmpr\Common\Cover\Container; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Common extends Container { const ecuwamcuymyycucq = Constants::ycusscwsoggmuweq . '_search_'; public function awwoqyciiocumkqq() { $ccamueccusigaaio = $this->caokeucsksukesyo()->giiecckwoyiawoyy()->yyqgamuwwakgciey(Constants::mgsccwumkcawaqcy, Constants::yyoaeaaaquyigiim); return $this->ocksiywmkyaqseou('search_target', $ccamueccusigaaio); } public function sesseaeskwkeucks() : string { $imuiukuiocoayoww = $this->weysguygiseoukqw(Setting::ocamcqaiuaogsgck, false); $mkwywaswweooyqeq = $this->weysguygiseoukqw(Setting::akqiiuumacyksaas, false); if ($imuiukuiocoayoww && $mkwywaswweooyqeq) { $sqeykgyoooqysmca = Constants::ygoseweigiigswiu; } else { if ($mkwywaswweooyqeq) { $sqeykgyoooqysmca = Constants::ucoiewcoucauqwko; } else { $sqeykgyoooqysmca = Constants::qgmuskygocwmouos; } } return $sqeykgyoooqysmca; } public function iemckwasmaugwcwi() : bool { return (bool) $this->weysguygiseoukqw(Setting::iquacaoiugwceesk); } }
