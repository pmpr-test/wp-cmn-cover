<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6bc133b1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Search; use Pmpr\Common\Cover\Container; use Pmpr\Common\Foundation\Interfaces\Constants; abstract class Common extends Container { const ecuwamcuymyycucq = Constants::ycusscwsoggmuweq . "\137\163\145\x61\162\143\x68\137"; public function awwoqyciiocumkqq() { $ccamueccusigaaio = $this->caokeucsksukesyo()->giiecckwoyiawoyy()->yyqgamuwwakgciey(Constants::mgsccwumkcawaqcy, Constants::yyoaeaaaquyigiim); return $this->ocksiywmkyaqseou("\163\x65\141\162\x63\150\137\164\141\x72\147\145\x74", $ccamueccusigaaio); } public function sesseaeskwkeucks() : string { $imuiukuiocoayoww = $this->weysguygiseoukqw(Setting::ocamcqaiuaogsgck, false); $mkwywaswweooyqeq = $this->weysguygiseoukqw(Setting::akqiiuumacyksaas, false); if ($imuiukuiocoayoww && $mkwywaswweooyqeq) { $sqeykgyoooqysmca = Constants::ygoseweigiigswiu; } else { if ($mkwywaswweooyqeq) { $sqeykgyoooqysmca = Constants::ucoiewcoucauqwko; } else { $sqeykgyoooqysmca = Constants::qgmuskygocwmouos; } } return $sqeykgyoooqysmca; } public function iemckwasmaugwcwi() : bool { return (bool) $this->weysguygiseoukqw(Setting::iquacaoiugwceesk); } }
