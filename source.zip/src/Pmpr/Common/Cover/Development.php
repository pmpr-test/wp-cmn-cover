<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb3b365c59             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\145\x76\x65\154\x6f\x70\x20\x61\156\144\40\x44\145\163\x69\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\x72\x64\160\x72\x65\163\x73\x2d\x77\145\x62\x2d\x64\145\163\x69\x67\156\x2d\x64\x65\166\x65\x6c\157\x70\155\145\x6e\164"); } }
