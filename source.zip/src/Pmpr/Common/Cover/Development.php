<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fcbc08ae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\x65\154\x6f\x70\x20\x61\156\144\40\104\x65\163\151\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\162\144\x70\162\145\163\x73\x2d\167\x65\x62\55\144\x65\163\x69\x67\156\55\x64\x65\166\145\x6c\x6f\160\155\145\156\164"); } }
