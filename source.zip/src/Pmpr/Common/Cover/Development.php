<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677bbeb0f13ce             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\166\145\x6c\x6f\x70\40\x61\156\x64\x20\x44\145\x73\x69\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\162\144\x70\162\x65\x73\x73\x2d\x77\145\x62\x2d\x64\145\x73\151\147\156\x2d\144\145\x76\145\x6c\x6f\x70\x6d\x65\156\x74"); } }
