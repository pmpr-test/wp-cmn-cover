<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705a35c717bc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\145\x76\x65\x6c\x6f\160\40\141\156\x64\x20\x44\x65\x73\151\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\x72\x64\x70\x72\145\163\163\x2d\x77\145\x62\55\x64\x65\163\151\147\156\x2d\144\145\x76\145\154\157\160\155\145\x6e\164"); } }
