<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a82c62f6b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\x76\145\154\157\160\40\141\156\x64\x20\104\x65\163\x69\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\x72\144\160\x72\145\x73\163\55\167\145\142\55\x64\x65\x73\x69\147\x6e\55\x64\x65\166\x65\154\x6f\160\x6d\x65\x6e\x74"); } }
