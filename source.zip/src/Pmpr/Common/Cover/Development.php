<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67802fccab824             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\166\145\x6c\x6f\160\40\141\x6e\x64\x20\104\x65\x73\x69\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\162\144\x70\x72\145\x73\x73\55\167\145\142\55\x64\145\163\x69\x67\156\x2d\144\145\x76\145\x6c\157\160\x6d\145\156\164"); } }
