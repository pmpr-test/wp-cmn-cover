<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6cfc9458             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\166\x65\x6c\157\x70\40\x61\x6e\x64\40\x44\145\x73\x69\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\x72\144\160\x72\x65\x73\x73\55\x77\x65\x62\x2d\144\145\163\151\147\156\55\x64\145\166\x65\154\157\160\x6d\145\156\164"); } }
