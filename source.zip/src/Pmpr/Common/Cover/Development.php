<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716beac1a112             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\145\166\145\154\157\160\40\x61\156\144\x20\104\x65\x73\151\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\157\x72\144\x70\162\145\x73\163\55\167\x65\x62\x2d\x64\x65\163\x69\147\x6e\55\144\145\x76\x65\154\x6f\x70\x6d\145\x6e\164"); } }
