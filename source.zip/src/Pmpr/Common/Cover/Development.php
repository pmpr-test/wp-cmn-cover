<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d5da7b40             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\145\166\145\x6c\x6f\160\40\x61\x6e\x64\40\x44\145\x73\151\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\157\162\x64\160\x72\145\x73\x73\55\x77\x65\x62\55\144\145\163\x69\147\x6e\55\x64\x65\x76\x65\x6c\x6f\160\155\145\x6e\x74"); } }
