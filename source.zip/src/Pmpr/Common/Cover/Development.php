<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed85a1ef6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\166\145\x6c\157\x70\x20\x61\156\x64\x20\x44\x65\163\151\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\162\x64\160\x72\x65\163\x73\55\x77\x65\x62\55\x64\145\x73\x69\147\156\55\144\145\x76\145\x6c\x6f\160\155\145\156\x74"); } }
