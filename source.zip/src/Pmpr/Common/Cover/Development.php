<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716c1864a4de             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\x65\154\x6f\x70\40\141\x6e\144\40\x44\x65\x73\151\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\157\x72\144\x70\x72\x65\x73\x73\55\x77\x65\x62\55\144\x65\163\151\147\x6e\55\x64\145\x76\x65\x6c\x6f\160\155\x65\x6e\164"); } }
