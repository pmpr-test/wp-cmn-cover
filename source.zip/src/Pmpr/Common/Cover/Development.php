<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb4132b7d7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\166\x65\154\x6f\160\40\141\156\x64\x20\104\145\x73\151\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\x72\x64\x70\162\x65\163\x73\55\x77\145\x62\x2d\x64\145\163\151\x67\156\x2d\x64\x65\166\x65\154\157\x70\x6d\x65\x6e\x74"); } }
