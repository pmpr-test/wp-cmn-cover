<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c383b33e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\166\145\154\x6f\x70\x20\141\156\x64\40\104\145\163\x69\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\x72\x64\160\162\145\163\163\55\167\x65\x62\55\x64\145\x73\x69\147\x6e\x2d\x64\145\166\x65\x6c\157\160\x6d\145\156\x74"); } }
