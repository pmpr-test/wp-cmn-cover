<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522cf24bc52             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\145\154\x6f\x70\40\x61\x6e\144\40\104\x65\x73\151\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\x72\x64\x70\162\x65\163\x73\55\167\145\x62\x2d\144\x65\163\151\x67\156\x2d\144\145\x76\x65\154\157\x70\155\145\156\164"); } }
