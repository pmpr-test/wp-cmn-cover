<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a80ef0b5c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\145\166\145\x6c\157\160\x20\x61\156\144\x20\x44\145\x73\x69\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\162\x64\160\x72\145\x73\x73\55\x77\145\142\55\x64\145\x73\x69\x67\156\55\x64\x65\166\x65\x6c\x6f\160\x6d\145\156\x74"); } }
