<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052cd52d7c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\x76\x65\x6c\157\x70\x20\x61\x6e\x64\x20\x44\145\163\x69\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\162\144\160\162\145\x73\x73\55\167\x65\142\55\144\x65\163\x69\x67\156\x2d\x64\x65\x76\145\154\157\x70\155\x65\156\x74"); } }
