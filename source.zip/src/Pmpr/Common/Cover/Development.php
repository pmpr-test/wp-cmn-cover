<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46a139fd0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\145\166\x65\x6c\x6f\160\40\141\x6e\x64\x20\x44\145\x73\x69\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\157\162\144\x70\x72\145\x73\x73\x2d\x77\x65\142\55\144\145\x73\151\x67\156\x2d\x64\145\x76\145\154\157\x70\155\145\x6e\164"); } }
