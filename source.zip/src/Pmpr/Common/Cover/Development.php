<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc05648ef2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\166\x65\154\x6f\160\x20\x61\x6e\144\40\x44\x65\x73\151\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\157\162\x64\x70\x72\x65\x73\163\55\x77\145\x62\x2d\144\x65\163\x69\147\x6e\x2d\144\145\x76\145\x6c\x6f\160\x6d\x65\x6e\164"); } }
