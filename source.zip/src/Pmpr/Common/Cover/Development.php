<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8503a050             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\145\154\x6f\x70\40\141\x6e\x64\40\104\145\163\x69\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\x72\x64\160\162\145\x73\x73\x2d\x77\145\x62\55\144\145\163\151\x67\156\x2d\x64\145\166\145\154\157\x70\x6d\x65\156\164"); } }
