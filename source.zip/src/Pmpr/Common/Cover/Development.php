<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4ad59a55             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\145\166\x65\154\x6f\x70\x20\141\x6e\144\x20\x44\145\163\151\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\162\144\x70\x72\145\163\163\x2d\167\145\x62\55\x64\145\x73\151\x67\x6e\55\x64\145\x76\145\x6c\157\x70\x6d\x65\x6e\x74"); } }
