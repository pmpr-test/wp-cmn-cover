<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cffeeccd8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\x65\x6c\157\x70\x20\141\x6e\x64\40\x44\x65\163\151\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\162\144\160\x72\145\x73\x73\x2d\x77\x65\142\x2d\x64\145\163\x69\147\156\55\144\145\166\x65\x6c\157\160\x6d\145\x6e\164"); } }
