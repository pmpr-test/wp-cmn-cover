<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d8eb9d924             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\145\x76\x65\x6c\x6f\160\40\x61\156\x64\40\104\x65\163\x69\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\x72\x64\160\162\145\x73\163\55\x77\145\142\x2d\x64\145\163\151\x67\156\55\144\x65\166\x65\154\157\160\x6d\x65\156\x74"); } }
