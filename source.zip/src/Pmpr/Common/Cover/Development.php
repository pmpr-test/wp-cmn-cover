<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038b8edf05             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\145\x76\x65\154\157\x70\40\141\x6e\x64\40\x44\x65\x73\x69\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\x72\x64\x70\x72\145\163\x73\x2d\x77\x65\142\55\144\x65\163\151\x67\156\55\x64\145\x76\145\x6c\x6f\x70\x6d\x65\x6e\x74"); } }
