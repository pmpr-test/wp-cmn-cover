<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67059fda52cde             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\166\145\154\x6f\x70\x20\141\156\144\40\x44\x65\163\151\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\x72\144\160\162\x65\163\x73\55\x77\x65\142\55\144\x65\163\151\x67\x6e\55\x64\145\x76\x65\x6c\x6f\x70\155\145\156\x74"); } }
