<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d43dca1b29             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\x76\145\x6c\x6f\160\40\x61\x6e\x64\x20\x44\x65\x73\x69\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\162\x64\160\x72\x65\x73\163\x2d\x77\x65\142\x2d\x64\145\163\151\147\x6e\x2d\144\145\x76\x65\154\x6f\x70\155\x65\156\x74"); } }
