<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678030c34fab8             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\145\166\x65\x6c\157\x70\40\141\156\x64\40\104\145\163\151\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\162\144\160\x72\145\x73\x73\x2d\x77\x65\142\55\x64\145\x73\151\x67\156\55\144\x65\x76\x65\x6c\x6f\x70\x6d\145\x6e\164"); } }
