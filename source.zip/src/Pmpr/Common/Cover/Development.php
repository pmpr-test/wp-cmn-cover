<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1cf64db5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\145\166\x65\154\x6f\x70\x20\x61\156\x64\40\x44\145\163\151\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\157\162\x64\x70\x72\x65\163\x73\x2d\167\x65\x62\x2d\144\x65\x73\151\x67\156\x2d\x64\145\x76\x65\x6c\x6f\160\x6d\x65\x6e\164"); } }
