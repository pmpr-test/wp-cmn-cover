<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a7b09bcd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\166\145\x6c\x6f\x70\40\x61\x6e\144\x20\x44\x65\163\x69\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\157\162\x64\160\x72\145\163\x73\55\167\x65\x62\x2d\x64\x65\163\151\x67\x6e\55\x64\145\166\145\154\x6f\160\155\145\x6e\x74"); } }
