<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd66b1d253             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\x76\145\x6c\157\160\x20\x61\156\144\x20\104\x65\x73\151\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\162\x64\160\162\x65\x73\163\x2d\167\145\x62\55\x64\145\163\151\x67\x6e\x2d\144\x65\x76\145\154\x6f\160\155\x65\x6e\164"); } }
