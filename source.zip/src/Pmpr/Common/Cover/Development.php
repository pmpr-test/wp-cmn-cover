<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038189a665             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\145\154\157\160\40\141\156\x64\40\104\145\163\151\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\x72\x64\160\162\x65\x73\163\55\x77\x65\142\x2d\x64\x65\163\151\147\x6e\55\144\x65\166\x65\154\157\x70\x6d\x65\156\x74"); } }
