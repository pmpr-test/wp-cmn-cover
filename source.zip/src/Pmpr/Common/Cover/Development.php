<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517377ff95             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\145\x76\x65\154\157\x70\40\141\156\x64\x20\104\x65\x73\151\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\162\x64\x70\x72\145\x73\163\55\167\145\142\x2d\144\145\163\151\x67\156\55\x64\145\166\x65\154\157\x70\155\145\156\x74"); } }
