<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4443ec418             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\145\x6c\x6f\160\x20\x61\156\x64\40\104\145\x73\x69\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\x72\144\x70\x72\145\x73\x73\x2d\167\145\142\x2d\x64\x65\163\x69\x67\156\55\x64\x65\x76\145\154\x6f\x70\x6d\145\x6e\x74"); } }
