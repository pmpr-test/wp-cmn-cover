<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b083ce992             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\166\x65\154\157\160\x20\x61\x6e\144\40\x44\145\x73\x69\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\x72\x64\x70\162\x65\x73\x73\55\x77\x65\x62\x2d\144\145\x73\x69\x67\x6e\x2d\144\145\166\x65\x6c\157\160\155\x65\156\164"); } }
