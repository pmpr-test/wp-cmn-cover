<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             674459939f07b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\166\x65\154\157\160\40\141\x6e\144\x20\x44\145\x73\151\x67\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\x72\x64\x70\162\x65\163\x73\55\x77\x65\x62\x2d\144\145\163\151\x67\x6e\55\144\145\x76\x65\154\x6f\160\155\145\x6e\164"); } }
