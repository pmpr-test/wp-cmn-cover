<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd411ad3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\145\x76\145\154\157\160\40\141\156\x64\40\x44\x65\x73\x69\147\x6e", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\x6f\x72\144\x70\x72\145\x73\x73\55\167\145\142\55\x64\145\163\151\147\x6e\x2d\x64\145\166\x65\154\157\x70\155\x65\x6e\x74"); } }
