<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7677fb1d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\x65\x76\145\x6c\157\160\x20\141\x6e\x64\x20\x44\145\163\151\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\157\162\x64\x70\x72\145\x73\163\x2d\x77\x65\142\55\x64\145\163\x69\147\156\x2d\x64\x65\166\x65\x6c\x6f\x70\155\145\x6e\x74"); } }
