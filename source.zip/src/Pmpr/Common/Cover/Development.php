<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae189491d0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\104\145\166\145\x6c\157\x70\x20\x61\156\144\x20\x44\x65\x73\151\147\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\167\157\x72\x64\x70\x72\x65\x73\163\55\167\145\x62\55\x64\x65\163\151\147\x6e\55\x64\145\x76\145\154\x6f\x70\x6d\145\x6e\164"); } }
