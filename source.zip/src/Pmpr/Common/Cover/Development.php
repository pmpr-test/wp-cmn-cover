<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6bc133b1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover; use Pmpr\Common\Foundation\Frontend\Page; class Development extends Page { public function qiccuiwooiquycsg() { $this->myysgyqcumekoueo()->oyaugcgekomyiiik()->gswweykyogmsyawy(__("\x44\x65\x76\x65\x6c\x6f\x70\40\141\x6e\144\x20\104\145\x73\151\x67\156", PR__CMN__COVER))->wegcaymyqqoyewmw("\x77\x6f\162\144\x70\162\145\163\x73\x2d\167\x65\x62\55\144\145\163\x69\x67\x6e\x2d\x64\x65\166\x65\x6c\157\160\155\145\156\x74"); } }
