<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705a35c717bc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment as BaseClass; class Segment extends BaseClass { public function ikcgmcycisiccyuc() { $this->setting = $this->caokeucsksukesyo()->ogciwyoqgciosgcw()->youaqkimaoecgsye(); } }
