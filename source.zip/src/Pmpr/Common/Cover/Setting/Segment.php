<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038b8edf05             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Segment as BaseClass; class Segment extends BaseClass { public function ikcgmcycisiccyuc() { $this->setting = $this->caokeucsksukesyo()->ogciwyoqgciosgcw()->youaqkimaoecgsye(); } }
