<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68a0be4d5ffbd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Setting; use Pmpr\Common\Foundation\FormGenerator\Backend\Setting\Section as BaseClass; use Pmpr\Common\Foundation\Interfaces\Constants; class Section extends BaseClass { public function ikcgmcycisiccyuc() { $this->segment = Constants::ioomakeyqiqowgmk; $this->setting = $this->caokeucsksukesyo()->ogciwyoqgciosgcw()->youaqkimaoecgsye(); } }
