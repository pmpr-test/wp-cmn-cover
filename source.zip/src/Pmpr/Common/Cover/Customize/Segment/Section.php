<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7677fb1d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Segment; use Pmpr\Common\Foundation\FormGenerator\Backend\Field\Field; class Section extends Segment { protected ?string $type = "\127\120\x5f\103\165\x73\164\157\155\151\172\145\137\123\145\143\164\x69\157\x6e"; protected array $fields = []; protected ?string $panel = null; public function ouuceooysqugqmee(?string $skeuoeoiuwwyqwou) : self { $this->panel = $skeuoeoiuwwyqwou; return $this; } public function ugmceccgwaaaigiy() : array { return $this->fields; } public function mkksewyosgeumwsa(Field $aiowsaccomcoikus) : self { $this->fields[$aiowsaccomcoikus->mwikyscisascoeea()] = $aiowsaccomcoikus; return $this; } public function ewweaossowcqywaw($ikgwqyuyckaewsow) : self { foreach ($ikgwqyuyckaewsow as $aiowsaccomcoikus) { $this->mkksewyosgeumwsa($aiowsaccomcoikus); smiemmcqqukyguuu: } quaqmuusokiyqgqe: return $this; } }
