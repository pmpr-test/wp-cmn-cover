<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7677fb1d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Customize\Segment; class Panel extends Segment { protected ?string $type = "\x57\120\x5f\x43\x75\163\x74\157\155\151\172\145\137\120\x61\x6e\145\x6c"; protected ?array $sections = []; public function suuogccckocgseyg() : ?array { return $this->sections; } public function kwkugmqouisgkqig(Section $awcmekyiwwkeyisq) : self { $awcmekyiwwkeyisq->ouuceooysqugqmee($this->mwikyscisascoeea()); $this->sections[$awcmekyiwwkeyisq->mwikyscisascoeea()] = $awcmekyiwwkeyisq; return $this; } }
