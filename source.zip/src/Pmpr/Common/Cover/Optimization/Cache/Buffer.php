<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             681fcb5041abc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Buffer { }
