<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67b6ff66e3be1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Buffer { }
