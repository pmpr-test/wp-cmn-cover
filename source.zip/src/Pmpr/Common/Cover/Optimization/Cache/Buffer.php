<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed85a1ef6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Buffer { }
