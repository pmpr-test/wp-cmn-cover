<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689c81572657e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; use Pmpr\Common\Cover\Optimization\Common as BaseClass; abstract class Common extends BaseClass { }
