<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6884a9d738bee             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; use Pmpr\Common\Cover\Optimization\Common as BaseClass; abstract class Common extends BaseClass { }
