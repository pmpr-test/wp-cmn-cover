<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6952c8c567008             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; use Pmpr\Common\Cover\Optimization\Common as BaseClass; abstract class Common extends BaseClass { }
