<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c383b33e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; use Pmpr\Common\Cover\Optimization\Common as BaseClass; abstract class Common extends BaseClass { }
