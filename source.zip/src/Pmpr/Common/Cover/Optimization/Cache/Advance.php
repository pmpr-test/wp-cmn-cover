<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c31f14d8a80             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Advance extends Common { }
