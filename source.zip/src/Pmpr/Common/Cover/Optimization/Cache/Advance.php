<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68e4de446b3dd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Advance extends Common { }
