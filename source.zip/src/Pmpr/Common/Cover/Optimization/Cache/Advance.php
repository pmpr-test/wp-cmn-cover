<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67c31f6e8c134             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Advance extends Common { }
