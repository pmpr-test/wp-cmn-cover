<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68169c3b24df9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Purge extends Common { }
