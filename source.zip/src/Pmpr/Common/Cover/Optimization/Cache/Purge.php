<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a80ef0b5c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Purge extends Common { }
