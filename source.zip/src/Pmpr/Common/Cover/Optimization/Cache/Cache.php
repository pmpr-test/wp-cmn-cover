<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             689c7ea1363b7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization\Cache; class Cache extends Common { }
