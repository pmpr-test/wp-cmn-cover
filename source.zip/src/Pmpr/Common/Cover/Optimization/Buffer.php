<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4443ec418             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\160\154\x61\164\x65\137\x72\x65\x64\151\x72\145\143\x74", [$this, "\x73\165\x79\x61\167\x79\x63\x69\165\145\143\145\x67\x67\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\145\x71\x6d\x6d\145\157\x67\x6f\167\x6f\x61\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\151\x6d\151\x7a\x61\x74\151\157\x6e\x5f\x62\x75\x66\146\145\162", $nsmgceoqaqogqmuw); } }
