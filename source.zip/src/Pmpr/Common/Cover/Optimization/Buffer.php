<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             68ac8583a10da             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu('template_redirect', [$this, 'suyawyciueceggaa'], 999); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, 'yuaeqmmeogowoaem']); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou('optimization_buffer', $nsmgceoqaqogqmuw); } }
