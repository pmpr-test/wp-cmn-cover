<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038b8edf05             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\x70\154\141\164\x65\x5f\162\x65\144\x69\162\x65\x63\164", [$this, "\x73\x75\171\x61\x77\171\x63\x69\165\x65\x63\x65\x67\x67\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\x61\145\x71\155\x6d\x65\157\x67\157\x77\157\x61\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\151\x6d\151\172\x61\164\151\157\156\x5f\x62\x75\x66\x66\145\162", $nsmgceoqaqogqmuw); } }
