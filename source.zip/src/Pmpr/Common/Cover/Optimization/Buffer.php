<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d87913155             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\x70\154\x61\x74\x65\137\x72\145\144\x69\x72\x65\143\164", [$this, "\163\x75\171\141\x77\171\x63\151\165\x65\x63\x65\x67\x67\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto kqyoakickmseyyeq; } ob_start([$this, "\x79\165\x61\x65\x71\155\x6d\145\x6f\x67\157\167\157\x61\x65\155"]); kqyoakickmseyyeq: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\151\155\151\172\x61\x74\x69\157\x6e\x5f\x62\165\146\x66\145\x72", $nsmgceoqaqogqmuw); } }
