<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a80ef0b5c             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\160\154\141\164\x65\x5f\162\145\x64\x69\162\x65\x63\164", [$this, "\163\x75\x79\x61\x77\171\143\x69\165\145\143\x65\x67\x67\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\x75\141\x65\x71\x6d\x6d\x65\x6f\147\157\167\x6f\141\145\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\x69\155\x69\x7a\141\164\x69\157\156\137\142\165\146\146\x65\x72", $nsmgceoqaqogqmuw); } }
