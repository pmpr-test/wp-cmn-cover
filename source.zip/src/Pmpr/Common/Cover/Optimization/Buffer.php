<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd804d337             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\160\x6c\141\164\145\x5f\x72\x65\144\151\162\145\143\164", [$this, "\x73\x75\x79\x61\167\x79\x63\x69\165\x65\143\145\147\x67\141\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\x65\161\155\155\x65\157\x67\x6f\x77\x6f\x61\145\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\x69\x6d\151\172\141\x74\x69\x6f\x6e\x5f\x62\165\x66\146\145\162", $nsmgceoqaqogqmuw); } }
