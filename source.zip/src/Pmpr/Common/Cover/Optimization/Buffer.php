<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             674458708a1bd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\x70\154\x61\164\x65\x5f\x72\x65\144\151\x72\145\x63\164", [$this, "\163\x75\171\141\x77\x79\143\x69\x75\x65\143\145\147\147\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\x75\x61\145\161\155\x6d\x65\x6f\x67\157\167\157\141\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\151\155\151\172\x61\x74\x69\157\x6e\x5f\142\165\x66\x66\x65\x72", $nsmgceoqaqogqmuw); } }
