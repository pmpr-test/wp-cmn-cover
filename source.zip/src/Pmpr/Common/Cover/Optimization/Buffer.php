<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522cf24bc52             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\x6d\x70\x6c\141\164\x65\x5f\x72\145\144\151\162\x65\x63\164", [$this, "\x73\x75\x79\141\167\171\143\151\x75\x65\x63\x65\x67\147\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\165\x61\x65\x71\155\155\145\157\147\x6f\167\x6f\x61\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\x74\x69\155\151\172\x61\x74\151\x6f\156\x5f\x62\165\146\146\145\162", $nsmgceoqaqogqmuw); } }
