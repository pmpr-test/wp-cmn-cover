<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517377ff95             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\160\x6c\141\x74\x65\137\162\145\144\151\x72\x65\x63\x74", [$this, "\163\165\171\141\167\x79\x63\x69\x75\x65\x63\145\x67\147\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto cwswueuqoamqasya; } ob_start([$this, "\171\x75\141\x65\161\155\155\145\157\147\157\x77\x6f\x61\x65\x6d"]); cwswueuqoamqasya: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\151\155\x69\x7a\141\164\151\x6f\156\x5f\142\x75\x66\146\145\162", $nsmgceoqaqogqmuw); } }
