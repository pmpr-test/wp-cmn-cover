<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d8eb9d924             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\160\154\x61\x74\145\137\x72\145\x64\x69\162\x65\143\164", [$this, "\x73\x75\x79\141\x77\171\x63\151\x75\145\x63\145\147\147\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto kqyoakickmseyyeq; } ob_start([$this, "\x79\x75\x61\145\x71\155\155\x65\x6f\x67\157\167\x6f\x61\145\x6d"]); kqyoakickmseyyeq: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\164\x69\x6d\151\x7a\x61\164\151\x6f\156\x5f\142\165\x66\146\145\162", $nsmgceoqaqogqmuw); } }
