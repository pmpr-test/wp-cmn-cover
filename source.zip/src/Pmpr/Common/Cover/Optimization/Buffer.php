<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670cffeeccd8b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\160\x6c\141\164\x65\137\x72\x65\x64\x69\x72\x65\143\164", [$this, "\x73\165\x79\x61\167\171\143\x69\165\145\x63\145\x67\x67\141\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\x65\x71\155\155\x65\x6f\147\x6f\167\157\x61\x65\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\x74\151\x6d\151\172\x61\164\x69\x6f\156\x5f\x62\x75\x66\x66\145\162", $nsmgceoqaqogqmuw); } }
