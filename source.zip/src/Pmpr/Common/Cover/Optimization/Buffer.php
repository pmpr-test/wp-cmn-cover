<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6bc133b1             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\x70\154\x61\164\x65\137\162\145\144\151\162\x65\143\x74", [$this, "\163\165\x79\141\x77\171\x63\x69\x75\145\x63\145\x67\147\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\x61\x65\x71\x6d\155\145\x6f\x67\x6f\x77\x6f\x61\145\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\151\x6d\151\x7a\141\164\x69\157\156\137\x62\x75\146\x66\x65\x72", $nsmgceoqaqogqmuw); } }
