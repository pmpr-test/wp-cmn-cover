<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb3b365c59             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\x70\154\141\x74\x65\x5f\x72\145\x64\x69\x72\x65\143\x74", [$this, "\163\165\171\141\167\x79\143\x69\x75\145\143\x65\147\x67\141\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto omykokikgocoikec; } ob_start([$this, "\x79\x75\141\145\161\155\x6d\145\x6f\x67\157\167\157\141\145\x6d"]); omykokikgocoikec: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\x69\x6d\x69\172\x61\x74\151\157\x6e\x5f\142\165\146\146\x65\x72", $nsmgceoqaqogqmuw); } }
