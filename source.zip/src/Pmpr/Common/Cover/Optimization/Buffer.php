<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1cf64db5f             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\160\x6c\141\x74\145\137\162\x65\x64\151\x72\145\x63\x74", [$this, "\163\165\x79\x61\167\171\x63\x69\x75\145\143\145\x67\147\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\165\141\x65\161\155\x6d\145\157\147\x6f\167\157\141\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\x74\x69\x6d\151\x7a\141\x74\151\x6f\156\x5f\x62\x75\146\x66\145\162", $nsmgceoqaqogqmuw); } }
