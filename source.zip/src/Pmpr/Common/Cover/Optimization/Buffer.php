<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e7677fb1d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\160\x6c\x61\164\145\137\162\x65\144\x69\162\x65\143\x74", [$this, "\x73\x75\x79\141\x77\171\x63\x69\x75\x65\143\x65\x67\147\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto gkqiqaqecmoogmaa; } ob_start([$this, "\x79\165\141\x65\x71\155\x6d\145\x6f\x67\157\167\x6f\x61\145\155"]); gkqiqaqecmoogmaa: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\164\151\155\x69\x7a\141\x74\x69\x6f\x6e\137\142\165\x66\146\x65\162", $nsmgceoqaqogqmuw); } }
