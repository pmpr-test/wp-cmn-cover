<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716c1864a4de             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\x70\x6c\141\164\145\x5f\x72\x65\144\151\x72\x65\x63\x74", [$this, "\163\165\x79\x61\167\171\143\151\165\x65\x63\x65\x67\x67\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\x75\141\145\161\x6d\x6d\145\157\147\157\167\157\141\145\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\164\x69\x6d\x69\172\141\164\x69\x6f\x6e\x5f\x62\x75\x66\x66\x65\162", $nsmgceoqaqogqmuw); } }
