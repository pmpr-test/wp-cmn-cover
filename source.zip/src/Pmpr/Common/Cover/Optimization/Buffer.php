<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb4132b7d7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\x70\x6c\x61\164\x65\137\162\145\x64\x69\162\145\143\x74", [$this, "\163\x75\x79\x61\167\x79\x63\x69\165\x65\x63\x65\x67\147\141\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto omykokikgocoikec; } ob_start([$this, "\171\165\141\145\x71\155\x6d\145\x6f\x67\157\x77\157\x61\145\155"]); omykokikgocoikec: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\151\155\151\172\x61\x74\x69\x6f\x6e\x5f\x62\x75\x66\x66\145\x72", $nsmgceoqaqogqmuw); } }
