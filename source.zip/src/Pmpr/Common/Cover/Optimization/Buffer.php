<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fcbc08ae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\160\154\141\x74\x65\137\162\145\144\151\162\x65\143\164", [$this, "\x73\x75\x79\x61\x77\x79\x63\x69\x75\x65\143\x65\x67\x67\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\145\161\x6d\x6d\145\157\x67\157\167\157\x61\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\151\x6d\151\x7a\141\x74\151\x6f\x6e\137\142\165\146\146\145\162", $nsmgceoqaqogqmuw); } }
