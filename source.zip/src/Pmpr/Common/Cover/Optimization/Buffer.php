<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67059fda52cde             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\x70\x6c\141\164\x65\x5f\162\145\144\x69\x72\145\x63\164", [$this, "\x73\x75\x79\141\167\x79\x63\x69\165\145\143\x65\147\147\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\x61\x65\x71\x6d\155\x65\x6f\147\x6f\167\x6f\141\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\151\x6d\x69\172\141\x74\x69\157\156\137\x62\x75\146\x66\145\x72", $nsmgceoqaqogqmuw); } }
