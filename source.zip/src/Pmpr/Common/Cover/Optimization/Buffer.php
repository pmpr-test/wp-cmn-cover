<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d5da7b40             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\x70\x6c\141\x74\145\x5f\162\145\x64\151\162\x65\x63\x74", [$this, "\163\165\x79\141\167\171\143\x69\165\x65\x63\145\x67\147\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\x65\161\x6d\x6d\x65\157\147\x6f\167\157\x61\x65\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\151\155\x69\x7a\141\x74\x69\x6f\x6e\x5f\142\165\x66\146\145\x72", $nsmgceoqaqogqmuw); } }
