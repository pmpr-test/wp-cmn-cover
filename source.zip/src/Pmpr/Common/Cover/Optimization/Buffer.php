<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc4ad59a55             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\x70\154\x61\x74\x65\x5f\162\145\144\x69\162\x65\143\x74", [$this, "\163\165\x79\141\x77\171\x63\151\165\x65\x63\x65\x67\x67\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\145\161\155\155\145\157\147\x6f\167\157\141\x65\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\x69\x6d\151\x7a\141\x74\x69\x6f\x6e\137\x62\x75\146\146\145\x72", $nsmgceoqaqogqmuw); } }
