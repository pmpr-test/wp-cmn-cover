<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052cd52d7c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\x70\154\141\x74\x65\137\162\x65\x64\151\162\145\x63\164", [$this, "\163\165\171\x61\167\171\143\x69\165\x65\x63\x65\x67\147\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\x61\x65\x71\x6d\155\145\157\147\157\x77\157\x61\x65\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\164\151\155\x69\x7a\x61\x74\x69\x6f\156\x5f\x62\165\146\x66\x65\x72", $nsmgceoqaqogqmuw); } }
