<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705b083ce992             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\160\154\x61\164\x65\x5f\x72\x65\x64\151\x72\x65\x63\x74", [$this, "\x73\x75\x79\x61\167\171\143\x69\x75\x65\143\x65\x67\147\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\141\145\161\155\155\x65\x6f\147\x6f\x77\x6f\141\x65\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\164\151\155\151\x7a\x61\x74\x69\x6f\156\137\x62\165\146\x66\x65\162", $nsmgceoqaqogqmuw); } }
