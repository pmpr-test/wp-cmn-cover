<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8503a050             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\160\x6c\141\164\145\x5f\162\x65\144\151\162\145\x63\164", [$this, "\x73\x75\x79\141\167\171\x63\151\x75\145\x63\x65\147\147\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto kqyoakickmseyyeq; } ob_start([$this, "\x79\165\141\145\x71\x6d\155\x65\x6f\147\157\x77\x6f\x61\x65\155"]); kqyoakickmseyyeq: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\x74\x69\x6d\x69\172\x61\164\151\157\156\x5f\142\165\x66\x66\145\x72", $nsmgceoqaqogqmuw); } }
