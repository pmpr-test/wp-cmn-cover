<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67802fccab824             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\160\x6c\141\x74\x65\137\x72\x65\144\151\x72\x65\x63\164", [$this, "\163\165\171\141\167\x79\x63\151\165\x65\x63\145\147\147\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\165\141\x65\x71\155\155\x65\157\x67\157\x77\157\141\x65\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\x74\x69\x6d\151\172\x61\164\x69\x6f\x6e\x5f\x62\165\x66\146\x65\x72", $nsmgceoqaqogqmuw); } }
