<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ebd411ad3             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\x70\154\141\x74\145\x5f\x72\145\x64\x69\x72\145\143\164", [$this, "\x73\165\171\141\167\171\143\151\165\145\143\x65\147\147\x61\141"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto gkqiqaqecmoogmaa; } ob_start([$this, "\x79\165\141\x65\161\x6d\x6d\145\157\147\x6f\167\157\141\x65\155"]); gkqiqaqecmoogmaa: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\x69\155\151\172\x61\164\x69\157\x6e\x5f\142\x75\x66\x66\x65\x72", $nsmgceoqaqogqmuw); } }
