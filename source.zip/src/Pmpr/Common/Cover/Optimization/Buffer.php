<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed85a1ef6d             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\x6d\160\154\x61\164\145\137\x72\145\144\151\162\x65\143\x74", [$this, "\x73\x75\x79\141\x77\x79\x63\x69\165\x65\x63\x65\147\x67\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\165\x61\145\161\x6d\155\145\157\147\x6f\x77\x6f\x61\145\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\151\155\x69\172\141\x74\x69\x6f\156\x5f\142\165\146\146\145\162", $nsmgceoqaqogqmuw); } }
