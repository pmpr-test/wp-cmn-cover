<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             671fc05648ef2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\155\160\154\x61\x74\145\137\x72\x65\x64\151\x72\145\x63\164", [$this, "\163\x75\x79\x61\167\x79\143\151\165\x65\x63\145\147\147\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\x61\145\161\x6d\155\x65\157\147\x6f\x77\x6f\141\145\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\x74\151\x6d\x69\x7a\x61\x74\x69\157\x6e\x5f\142\165\146\x66\145\162", $nsmgceoqaqogqmuw); } }
