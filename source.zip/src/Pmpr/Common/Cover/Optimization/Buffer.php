<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705a35c717bc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\x70\154\141\x74\145\x5f\x72\145\144\x69\162\145\x63\164", [$this, "\x73\x75\171\x61\x77\171\x63\151\x75\145\143\x65\x67\147\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\x75\x61\145\161\155\155\x65\x6f\147\157\167\x6f\x61\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\151\x6d\x69\172\x61\164\151\157\x6e\137\142\165\x66\146\145\162", $nsmgceoqaqogqmuw); } }
