<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677bbeb0f13ce             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\x70\154\141\x74\x65\137\x72\x65\x64\151\162\x65\143\164", [$this, "\x73\165\x79\x61\167\x79\143\151\x75\145\143\x65\x67\x67\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\141\x65\x71\155\155\x65\x6f\147\x6f\x77\157\x61\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\164\151\x6d\151\172\x61\164\x69\x6f\156\x5f\142\165\x66\x66\x65\162", $nsmgceoqaqogqmuw); } }
