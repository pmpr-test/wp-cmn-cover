<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673b8c383b33e             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\x65\x6d\160\x6c\x61\x74\145\x5f\162\x65\x64\151\162\145\143\x74", [$this, "\163\165\x79\x61\167\x79\x63\151\165\145\143\x65\147\x67\141\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\141\x65\x71\155\x6d\x65\x6f\x67\x6f\167\x6f\141\145\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\x74\x69\155\151\x7a\141\164\x69\x6f\x6e\137\x62\165\x66\x66\145\162", $nsmgceoqaqogqmuw); } }
