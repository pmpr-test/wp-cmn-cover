<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716beac1a112             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\155\x70\x6c\141\x74\x65\x5f\162\x65\144\x69\162\x65\x63\164", [$this, "\163\x75\x79\x61\167\171\x63\151\165\x65\x63\145\147\x67\141\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\x61\x65\x71\155\x6d\x65\157\147\x6f\167\157\141\x65\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\151\x6d\x69\x7a\x61\164\151\157\x6e\137\x62\x75\x66\146\x65\x72", $nsmgceoqaqogqmuw); } }
