<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6716d88946bbc             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\x70\x6c\x61\x74\x65\x5f\162\145\x64\151\162\145\143\x74", [$this, "\x73\165\171\141\x77\x79\x63\151\x75\x65\143\145\x67\147\141\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\165\x61\x65\161\155\155\x65\x6f\147\x6f\x77\x6f\x61\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\x74\151\155\151\172\x61\x74\151\157\x6e\137\142\x75\x66\146\x65\162", $nsmgceoqaqogqmuw); } }
