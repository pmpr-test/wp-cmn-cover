<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46a139fd0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\160\154\x61\164\x65\x5f\x72\145\144\x69\x72\x65\x63\x74", [$this, "\163\165\171\x61\x77\x79\x63\x69\x75\145\143\145\147\147\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\x75\141\x65\x71\155\x6d\145\x6f\x67\x6f\x77\157\x61\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\164\x69\155\x69\172\x61\x74\151\157\x6e\137\x62\x75\x66\146\x65\162", $nsmgceoqaqogqmuw); } }
