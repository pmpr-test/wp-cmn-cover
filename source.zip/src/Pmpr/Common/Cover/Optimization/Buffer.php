<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6786e841c4cb2             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\x70\x6c\x61\x74\x65\137\162\145\144\x69\162\145\x63\x74", [$this, "\163\165\x79\x61\167\x79\x63\151\x75\x65\x63\x65\x67\x67\141\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\x61\145\161\155\x6d\x65\157\x67\x6f\167\157\x61\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\x74\151\155\151\172\141\x74\151\157\x6e\137\142\x75\x66\x66\x65\162", $nsmgceoqaqogqmuw); } }
