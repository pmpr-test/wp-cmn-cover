<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678038189a665             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\x70\154\141\x74\x65\137\x72\x65\x64\x69\162\145\143\x74", [$this, "\x73\x75\171\x61\x77\x79\x63\x69\165\x65\x63\145\x67\147\x61\x61"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\x75\141\x65\161\155\x6d\x65\x6f\147\x6f\167\x6f\141\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\151\155\151\172\141\x74\151\157\x6e\x5f\x62\x75\x66\146\145\162", $nsmgceoqaqogqmuw); } }
