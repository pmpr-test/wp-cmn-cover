<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae189491d0             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\145\155\160\x6c\x61\x74\145\x5f\x72\x65\x64\151\162\x65\143\x74", [$this, "\x73\165\171\x61\x77\171\x63\x69\x75\145\143\145\x67\x67\x61\x61"]); } public function suyawyciueceggaa() { if (!$this->macyowwkykkuosce()) { goto gkqiqaqecmoogmaa; } ob_start([$this, "\x79\x75\x61\x65\161\x6d\155\x65\x6f\147\157\167\x6f\141\x65\155"]); gkqiqaqecmoogmaa: } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\160\164\x69\x6d\151\172\141\x74\151\x6f\x6e\137\142\165\x66\x66\x65\162", $nsmgceoqaqogqmuw); } }
