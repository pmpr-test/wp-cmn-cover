<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a7b09bcd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\155\x70\x6c\x61\x74\145\x5f\162\x65\144\x69\162\x65\x63\x74", [$this, "\163\x75\x79\x61\x77\x79\x63\x69\165\x65\x63\145\147\x67\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\x79\165\x61\x65\x71\155\x6d\x65\157\147\x6f\167\157\x61\145\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\x6f\x70\x74\x69\x6d\151\x7a\x61\x74\x69\x6f\156\137\142\165\146\x66\145\162", $nsmgceoqaqogqmuw); } }
