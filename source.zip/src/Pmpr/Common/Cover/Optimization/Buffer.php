<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670ed8109666a             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\164\145\x6d\x70\x6c\141\x74\x65\x5f\x72\x65\x64\151\162\x65\143\164", [$this, "\163\x75\171\141\x77\171\x63\151\165\x65\x63\x65\x67\147\141\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\145\161\x6d\155\x65\157\147\157\x77\157\141\x65\155"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\160\x74\151\155\151\172\x61\x74\151\x6f\156\137\142\165\x66\146\x65\x72", $nsmgceoqaqogqmuw); } }
