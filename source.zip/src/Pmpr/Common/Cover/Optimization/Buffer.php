<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a82c62f6b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; class Buffer extends Common { public function wigskegsqequoeks() { $this->qcsmikeggeemccuu("\x74\x65\x6d\x70\154\141\164\145\137\162\145\144\x69\x72\145\143\x74", [$this, "\163\165\171\141\167\x79\x63\151\x75\145\x63\x65\147\147\x61\141"]); } public function suyawyciueceggaa() { if ($this->macyowwkykkuosce()) { ob_start([$this, "\171\165\141\145\x71\x6d\155\145\x6f\x67\x6f\167\x6f\141\x65\x6d"]); } } public function yuaeqmmeogowoaem($nsmgceoqaqogqmuw) { return $this->ocksiywmkyaqseou("\157\x70\164\151\x6d\x69\172\x61\164\x69\157\156\x5f\142\165\146\146\x65\162", $nsmgceoqaqogqmuw); } }
