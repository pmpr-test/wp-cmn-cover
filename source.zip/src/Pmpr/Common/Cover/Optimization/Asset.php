<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             673bbd804d337             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\x2f\x74\x79\160\145\75\133\47\x22\135\164\145\170\164\x5c\57\x28\152\141\166\141\x73\x63\162\x69\x70\164\x7c\143\163\x73\51\x5b\47\42\x5d\x2f", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
