<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677bbeb0f13ce             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\57\164\171\160\x65\x3d\x5b\x27\42\135\x74\x65\170\164\x5c\57\x28\x6a\141\166\x61\x73\x63\x72\151\160\x74\174\x63\x73\163\x29\x5b\47\42\135\57", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
