<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66f7d87913155             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\x2f\x74\171\160\145\x3d\x5b\47\x22\135\x74\145\x78\164\x5c\57\x28\x6a\x61\x76\x61\x73\143\162\151\160\164\x7c\143\x73\x73\51\x5b\x27\x22\x5d\x2f", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
