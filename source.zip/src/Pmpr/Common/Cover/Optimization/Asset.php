<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4a7b09bcd             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\57\x74\171\160\145\x3d\133\x27\x22\135\x74\x65\x78\164\134\x2f\x28\x6a\141\x76\x61\163\x63\x72\151\160\164\174\x63\x73\163\51\133\47\x22\135\x2f", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
