<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbb4132b7d7             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\x2f\164\171\160\145\x3d\133\x27\x22\135\x74\145\170\164\134\x2f\50\152\x61\x76\x61\x73\x63\162\151\x70\x74\x7c\143\163\x73\51\133\47\x22\x5d\x2f", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
