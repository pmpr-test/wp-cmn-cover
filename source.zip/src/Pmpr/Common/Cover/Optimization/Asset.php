<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             678a9fcbc08ae             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\x2f\x74\x79\160\145\x3d\133\x27\42\135\x74\x65\x78\164\x5c\57\x28\x6a\141\166\141\x73\143\x72\x69\160\x74\174\x63\163\x73\x29\x5b\47\42\135\x2f", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
