<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6751a82c62f6b             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\x2f\164\171\x70\145\75\x5b\x27\42\x5d\164\145\x78\x74\134\x2f\50\152\141\166\x61\163\143\x72\151\160\x74\174\x63\163\x73\51\x5b\47\42\x5d\x2f", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
