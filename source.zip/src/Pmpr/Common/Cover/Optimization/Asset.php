<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67522cf24bc52             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\57\x74\x79\160\145\x3d\x5b\x27\42\x5d\164\x65\170\164\x5c\x2f\50\152\x61\x76\141\163\143\162\151\160\164\x7c\143\163\x73\51\x5b\x27\42\x5d\57", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
