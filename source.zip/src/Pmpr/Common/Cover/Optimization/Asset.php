<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67052cd52d7c9             |
    |_______________________________________|
*/
 namespace Pmpr\Common\Cover\Optimization; use Exception; class Asset extends Common { public function aqgugcgmsyciswgs($moooemyaqewumiay) { try { $moooemyaqewumiay = (string) preg_replace("\57\x74\x79\x70\x65\x3d\133\47\x22\135\164\x65\170\x74\x5c\x2f\50\x6a\x61\x76\x61\x73\143\162\x69\160\164\174\143\x73\x73\51\133\x27\42\x5d\x2f", '', $moooemyaqewumiay); } catch (Exception $wgaoewqkwgomoaai) { } return $moooemyaqewumiay; } }
