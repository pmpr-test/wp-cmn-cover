<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd66b1d253             |
    |_______________________________________|
*/
 use Pmpr\Common\Cover\Setting\Setting; use Pmpr\Common\Cover\Cover; Cover::symcgieuakksimmu(); if (!function_exists("\147\x65\164\x5f\x63\157\166\x65\x72\x5f\163\145\164\x74\151\156\x67")) { function get_cover_setting($uusmaiomayssaecw, $ggauoeuaesiymgee = null) { return Setting::eiwcuqigayigimak($uusmaiomayssaecw, $ggauoeuaesiymgee); } }
