<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6705a35c717bc             |
    |_______________________________________|
*/
 use Pmpr\Common\Cover\Cover; Cover::symcgieuakksimmu(); if (!function_exists("\x67\145\164\x5f\143\157\166\145\162\x5f\163\x65\x74\x74\151\x6e\x67")) { function get_cover_setting($uusmaiomayssaecw, $ggauoeuaesiymgee = null) { return Cover::symcgieuakksimmu()->weysguygiseoukqw($uusmaiomayssaecw, $ggauoeuaesiymgee); } }
