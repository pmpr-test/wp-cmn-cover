<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66fbd6cfc9458             |
    |_______________________________________|
*/
 use Pmpr\Common\Cover\Setting\Setting; use Pmpr\Common\Cover\Cover; Cover::symcgieuakksimmu(); if (!function_exists("\147\145\164\137\143\157\x76\145\162\x5f\x73\145\164\164\x69\156\147")) { function get_cover_setting($uusmaiomayssaecw, $ggauoeuaesiymgee = null) { return Setting::eiwcuqigayigimak($uusmaiomayssaecw, $ggauoeuaesiymgee); } }
